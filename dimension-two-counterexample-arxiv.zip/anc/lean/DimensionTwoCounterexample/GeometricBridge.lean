import DimensionTwoCounterexample.CounterexampleStatement
import DimensionTwoCounterexample.DegreeFromIrreducible
import DimensionTwoCounterexample.ActualIrreducibility

/-!
# The geometric generic-fiber bridge

This module separates the formal geometric bridge into three exact steps:

1. sections of the geometric generic fiber are compatible maps to the source;
2. compatible maps of affine schemes are compatible maps of coordinate rings;
3. compatible coordinate-ring maps are algebra homomorphisms over the target.

The first two steps use only the pullback universal property and the affine
`Spec` equivalence.  In particular, they do not require an explicit
tensor-product presentation of the pullback.

The final field-theoretic equivalence additionally needs reconstruction of an
arbitrary compatible coordinate-ring point from the image of the primitive
element `w`.  Cubic irreducibility is an explicit hypothesis of that step; it
is not reproved here.
-/

namespace DimensionTwoCounterexample.Final.GeometricBridge

open CategoryTheory
open CategoryTheory.Limits

noncomputable section

abbrev CompatibleSpecMap : Type _ :=
  { h :
      AlgebraicGeometry.Spec (.of GeometricClosure) ⟶
        AlgebraicGeometry.Spec (.of SourceRing) //
    h ≫ affineMap = geometricGenericPoint }

abbrev CompatibleCommRingMap : Type _ :=
  { f :
      CommRingCat.of SourceRing ⟶ CommRingCat.of GeometricClosure //
    CommRingCat.ofHom coordinateRingHom ≫ f =
      CommRingCat.ofHom targetToGeometricClosure }

def sectionToCompatibleSpecMap
    (s : GeometricGenericFiberPoint) : CompatibleSpecMap := by
  refine ⟨s.1 ≫ pullback.fst affineMap geometricGenericPoint, ?_⟩
  calc
    (s.1 ≫ pullback.fst affineMap geometricGenericPoint) ≫ affineMap =
        s.1 ≫
          (pullback.fst affineMap geometricGenericPoint ≫ affineMap) := by
            simp
    _ = s.1 ≫
          (pullback.snd affineMap geometricGenericPoint ≫
            geometricGenericPoint) := by
              rw [pullback.condition]
    _ = (s.1 ≫ pullback.snd affineMap geometricGenericPoint) ≫
          geometricGenericPoint := by
            simp
    _ = geometricGenericPoint := by
      simpa [geometricGenericFiberProjection] using
        congrArg (fun t => t ≫ geometricGenericPoint) s.2

def compatibleSpecMapToSection
    (h : CompatibleSpecMap) : GeometricGenericFiberPoint := by
  refine
    ⟨pullback.lift h.1 (𝟙 _) ?_,
      ?_⟩
  · simpa using h.2
  · simp [geometricGenericFiberProjection]

noncomputable def sectionCompatibleSpecMapEquiv :
    GeometricGenericFiberPoint ≃ CompatibleSpecMap where
  toFun := sectionToCompatibleSpecMap
  invFun := compatibleSpecMapToSection
  left_inv := by
    intro s
    apply Subtype.ext
    apply pullback.hom_ext
    · simp [sectionToCompatibleSpecMap, compatibleSpecMapToSection]
    · simpa [compatibleSpecMapToSection, geometricGenericFiberProjection] using
        s.2.symm
  right_inv := by
    intro h
    apply Subtype.ext
    simp [sectionToCompatibleSpecMap, compatibleSpecMapToSection]

def compatibleSpecMapToCommRingMap
    (h : CompatibleSpecMap) : CompatibleCommRingMap := by
  refine ⟨AlgebraicGeometry.Spec.preimage h.1, ?_⟩
  have hpreimage := congrArg AlgebraicGeometry.Spec.preimage h.2
  simpa [affineMap, geometricGenericPoint] using hpreimage

def compatibleCommRingMapToSpecMap
    (f : CompatibleCommRingMap) : CompatibleSpecMap := by
  refine ⟨AlgebraicGeometry.Spec.map f.1, ?_⟩
  apply AlgebraicGeometry.Spec.homEquiv.injective
  simpa [affineMap, geometricGenericPoint] using f.2

noncomputable def compatibleSpecMapCommRingMapEquiv :
    CompatibleSpecMap ≃ CompatibleCommRingMap where
  toFun := compatibleSpecMapToCommRingMap
  invFun := compatibleCommRingMapToSpecMap
  left_inv := by
    intro h
    apply Subtype.ext
    simp [compatibleSpecMapToCommRingMap, compatibleCommRingMapToSpecMap]
  right_inv := by
    intro f
    apply Subtype.ext
    simp [compatibleSpecMapToCommRingMap, compatibleCommRingMapToSpecMap]

local instance targetFunctionFieldGeometricClosureAlgebra :
    Algebra TargetFunctionField GeometricClosure :=
  AlgebraicClosure.instAlgebra (k := TargetFunctionField)

noncomputable def geometricFiberPointCompatibleCommRingMapEquiv :
    GeometricGenericFiberPoint ≃ CompatibleCommRingMap :=
  sectionCompatibleSpecMapEquiv.trans <|
    compatibleSpecMapCommRingMapEquiv

private theorem hidden_integral :
    IsIntegral TargetFunctionField
      (Reconstruction.w (k := k)) :=
  ⟨FieldExtension.cubic (k := k),
    FieldExtension.cubic_monic (k := k),
    FieldExtension.cubic_root (k := k)⟩

noncomputable def hiddenPowerBasis :
    PowerBasis TargetFunctionField SourceFunctionField :=
  (IntermediateField.adjoin.powerBasis hidden_integral).map
    ((IntermediateField.equivOfEq
      (FieldExtension.adjoin_hidden_eq_top (k := k))).trans
        IntermediateField.topEquiv)

@[simp]
theorem hiddenPowerBasis_gen :
    hiddenPowerBasis.gen = Reconstruction.w (k := k) := by
  simp [hiddenPowerBasis, IntermediateField.equivOfEq,
    Subalgebra.equivOfEq, IntermediateField.topEquiv]
  rfl

private theorem compatible_commutes
    (f : CompatibleCommRingMap)
    (t : TargetRing) :
    f.1.hom (coordinateRingHom t) = targetToGeometricClosure t := by
  have h := congrArg
    (fun g :
      CommRingCat.of TargetRing ⟶ CommRingCat.of GeometricClosure => g t)
    f.2
  exact h

private theorem compatible_map_P
    (f : CompatibleCommRingMap) :
    f.1.hom sourceP =
      algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 0) := by
  calc
    f.1.hom sourceP =
        f.1.hom (coordinateRingHom (MvPolynomial.X 0 : TargetRing)) := by
          congr 1
          simp [coordinateRingHom, coordinateAlgHom, outputPolynomial, sourceP]
    _ = targetToGeometricClosure (MvPolynomial.X 0) :=
      compatible_commutes f _
    _ = algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 0) := by
      apply congrArg (algebraMap TargetFunctionField GeometricClosure)
      apply Subtype.ext
      simp [targetToTargetFunctionField, targetFamilyInTargetFunctionField,
        targetFamily, pInFunctionField, sourceToFunctionField,
        FieldExtension.targetInE, FieldExtension.target,
        Reconstruction.P, Reconstruction.includePolynomial]
      rfl

private theorem compatible_map_Q
    (f : CompatibleCommRingMap) :
    f.1.hom sourceQ =
      algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 1) := by
  calc
    f.1.hom sourceQ =
        f.1.hom (coordinateRingHom (MvPolynomial.X 1 : TargetRing)) := by
          congr 1
          simp [coordinateRingHom, coordinateAlgHom, outputPolynomial, sourceQ]
    _ = targetToGeometricClosure (MvPolynomial.X 1) :=
      compatible_commutes f _
    _ = algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 1) := by
      apply congrArg (algebraMap TargetFunctionField GeometricClosure)
      apply Subtype.ext
      simp [targetToTargetFunctionField, targetFamilyInTargetFunctionField,
        targetFamily, qInFunctionField, sourceToFunctionField,
        FieldExtension.targetInE, FieldExtension.target,
        Reconstruction.Q, Reconstruction.includePolynomial]
      rfl

private theorem embedding_map_P
    (φ : SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :
    φ (sourceToFunctionField sourceP) =
      algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 0) := by
  change
    φ (algebraMap TargetFunctionField SourceFunctionField
      (FieldExtension.targetInE (k := k) 0)) =
        algebraMap TargetFunctionField GeometricClosure
          (FieldExtension.targetInE (k := k) 0)
  exact φ.commutes _

private theorem embedding_map_Q
    (φ : SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :
    φ (sourceToFunctionField sourceQ) =
      algebraMap TargetFunctionField GeometricClosure
        (FieldExtension.targetInE (k := k) 1) := by
  change
    φ (algebraMap TargetFunctionField SourceFunctionField
      (FieldExtension.targetInE (k := k) 1)) =
        algebraMap TargetFunctionField GeometricClosure
          (FieldExtension.targetInE (k := k) 1)
  exact φ.commutes _

private theorem compatible_hidden_root
    (hirr : Irreducible (FieldExtension.cubic (k := k)))
    (f : CompatibleCommRingMap) :
    Polynomial.aeval (f.1.hom sourcew)
      (minpoly TargetFunctionField hiddenPowerBasis.gen) = 0 := by
  rw [show minpoly TargetFunctionField hiddenPowerBasis.gen =
      FieldExtension.cubic (k := k) by
    simpa only [hiddenPowerBasis_gen] using
      DegreeFromIrreducible.minpoly_eq_cubic (k := k) hirr]
  have h :
      f.1.hom sourcew ^ 3 + f.1.hom sourcew ^ 2 +
          (f.1.hom sourceP * f.1.hom sourceQ + f.1.hom sourceP ^ 3) *
            f.1.hom sourcew +
        f.1.hom sourceP ^ 3 = 0 := by
    simpa [sourcew, sourceP, sourceQ] using
      congrArg f.1.hom (Generic.cubic_root (k := k))
  rw [Polynomial.aeval_def]
  simp only [FieldExtension.cubic, Polynomial.eval₂_add,
    Polynomial.eval₂_pow, Polynomial.eval₂_mul, Polynomial.eval₂_X,
    RingHom.map_add, RingHom.map_mul, RingHom.map_pow]
  rw [Polynomial.eval₂_C (a := FieldExtension.targetInE (k := k) 0)
      (algebraMap TargetFunctionField GeometricClosure) (f.1.hom sourcew),
    Polynomial.eval₂_C (a := FieldExtension.targetInE (k := k) 1)
      (algebraMap TargetFunctionField GeometricClosure) (f.1.hom sourcew)]
  erw [← compatible_map_P f, ← compatible_map_Q f]
  exact h

noncomputable def compatibleAlgHomToFunctionFieldEmbedding
    (hirr : Irreducible (FieldExtension.cubic (k := k)))
    (f : CompatibleCommRingMap) :
    SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure :=
  hiddenPowerBasis.lift (f.1.hom sourcew) (compatible_hidden_root hirr f)

noncomputable def functionFieldEmbeddingToCompatibleAlgHom
    (φ : SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :
    CompatibleCommRingMap := by
  refine ⟨CommRingCat.ofHom (φ.toRingHom.comp sourceToFunctionField), ?_⟩
  apply CommRingCat.hom_ext
  apply RingHom.ext
  intro t
  change
    φ (sourceToFunctionField (coordinateRingHom t)) =
      targetToGeometricClosure t
  have hfactor :
      sourceToFunctionField (coordinateRingHom t) =
        algebraMap TargetFunctionField SourceFunctionField
          (targetToTargetFunctionField t) := by
    have hRing :
        sourceToFunctionField.comp coordinateRingHom =
          (algebraMap TargetFunctionField SourceFunctionField).comp
            targetToTargetFunctionField.toRingHom := by
      apply MvPolynomial.ringHom_ext
      · intro a
        simpa [coordinateRingHom, coordinateAlgHom, sourceToFunctionField,
          targetToTargetFunctionField] using
          (IsScalarTower.algebraMap_apply
            k SourceRing SourceFunctionField a)
      · intro i
        fin_cases i
        · simp [coordinateRingHom, coordinateAlgHom, outputPolynomial,
            sourceP, targetToTargetFunctionField,
            targetFamilyInTargetFunctionField, targetFamily,
            pInFunctionField, sourceToFunctionField]
        · simp [coordinateRingHom, coordinateAlgHom, outputPolynomial,
            sourceQ, targetToTargetFunctionField,
            targetFamilyInTargetFunctionField, targetFamily,
            qInFunctionField, sourceToFunctionField]
    exact DFunLike.congr_fun hRing t
  calc
    φ (sourceToFunctionField (coordinateRingHom t)) =
        φ (algebraMap TargetFunctionField SourceFunctionField
          (targetToTargetFunctionField t)) := by rw [hfactor]
    _ = algebraMap TargetFunctionField GeometricClosure
        (targetToTargetFunctionField t) := φ.commutes _
    _ = targetToGeometricClosure t := rfl

private theorem source_xy_eq_q_add_one :
    sourceX * sourceY = sourceq + 1 := by
  calc
    sourceX * sourceY = 1 + (1 + sourceX * sourceY) :=
      (CharTwo.add_cancel_left 1 (sourceX * sourceY)).symm
    _ = 1 + sourceq := by
      rw [show sourceq = 1 + sourceX * sourceY by
        rfl]
    _ = sourceq + 1 := add_comm _ _

private theorem restrict_lift_eq
    (hirr : Irreducible (FieldExtension.cubic (k := k)))
    (f : CompatibleCommRingMap) :
    functionFieldEmbeddingToCompatibleAlgHom
        (compatibleAlgHomToFunctionFieldEmbedding hirr f) = f := by
  let φ := compatibleAlgHomToFunctionFieldEmbedding hirr f
  let ψ : SourceFunctionField →+* GeometricClosure := φ.toRingHom
  have hw :
      ψ (Reconstruction.w (k := k)) = f.1.hom sourcew := by
    change hiddenPowerBasis.lift (f.1.hom sourcew) _
      hiddenPowerBasis.gen = f.1.hom sourcew
    exact hiddenPowerBasis.lift_gen _ _
  have hP :
      ψ (Reconstruction.P (k := k)) = f.1.hom sourceP :=
    (embedding_map_P φ).trans (compatible_map_P f).symm
  have hQ :
      ψ (Reconstruction.Q (k := k)) = f.1.hom sourceQ :=
    (embedding_map_Q φ).trans (compatible_map_Q f).symm
  have hQ0 : ψ (Reconstruction.Q (k := k)) ≠ 0 := by
    intro h
    apply Reconstruction.Q_ne_zero (k := k)
    apply φ.injective
    simpa using h
  have hx :
      ψ (Reconstruction.x (k := k)) = f.1.hom sourceX := by
    apply mul_right_cancel₀ hQ0
    calc
      ψ (Reconstruction.x (k := k)) *
          ψ (Reconstruction.Q (k := k)) =
          1 + ψ (Reconstruction.w (k := k)) := by
            rw [← ψ.map_mul, ← ψ.map_one, ← ψ.map_add]
            exact congrArg ψ.toFun
              (Reconstruction.recovery_x_mapped (k := k))
      _ = 1 + f.1.hom sourcew := by rw [hw]
      _ = f.1.hom sourceX * f.1.hom sourceQ := by
        simpa [sourceX, sourceQ, sourcew] using
          (congrArg f.1.hom (Generic.recovery_x (k := k))).symm
      _ = f.1.hom sourceX * ψ (Reconstruction.Q (k := k)) := by rw [hQ]
  have hx0 : ψ (Reconstruction.x (k := k)) ≠ 0 := by
    intro h
    apply Reconstruction.x_ne_zero (k := k)
    apply φ.injective
    simpa using h
  have hw0 : ψ (Reconstruction.w (k := k)) ≠ 0 := by
    intro h
    apply Reconstruction.w_ne_zero (k := k)
    apply φ.injective
    simpa using h
  have hsourceRecoveryQ :
      sourceP ^ 2 = sourceX ^ 2 * sourceq * sourcew := by
    simpa only [sourceX, sourceP, sourceq, sourcew] using
      (Generic.recovery_q (k := k))
  have hq :
      ψ (Reconstruction.q (k := k)) = f.1.hom sourceq := by
    apply mul_right_cancel₀
      (mul_ne_zero (pow_ne_zero 2 hx0) hw0)
    calc
      ψ (Reconstruction.q (k := k)) *
          (ψ (Reconstruction.x (k := k)) ^ 2 *
            ψ (Reconstruction.w (k := k))) =
          ψ (Reconstruction.x (k := k)) ^ 2 *
            ψ (Reconstruction.q (k := k)) *
              ψ (Reconstruction.w (k := k)) := by ac_rfl
      _ = ψ
          (Reconstruction.x (k := k) ^ 2 *
            Reconstruction.q (k := k) *
              Reconstruction.w (k := k)) := by
        rw [ψ.map_mul, ψ.map_mul, ψ.map_pow]
      _ = ψ (Reconstruction.P (k := k) ^ 2) := by
        rw [← Reconstruction.recovery_q_mapped (k := k)]
      _ = ψ (Reconstruction.P (k := k)) ^ 2 := by
        rw [ψ.map_pow]
      _ = (f.1.hom sourceP) ^ 2 := by rw [hP]
      _ = f.1.hom (sourceP ^ 2) := by
        rw [map_pow]
      _ = f.1.hom (sourceX ^ 2 * sourceq * sourcew) := by
        exact congrArg f.1.hom hsourceRecoveryQ
      _ = (f.1.hom sourceX) ^ 2 * f.1.hom sourceq * f.1.hom sourcew := by
        rw [map_mul, map_mul, map_pow]
      _ = f.1.hom sourceq *
          (ψ (Reconstruction.x (k := k)) ^ 2 *
            ψ (Reconstruction.w (k := k))) := by
        rw [hx, hw]
        ac_rfl
  have hy :
      ψ (Reconstruction.y (k := k)) = f.1.hom sourceY := by
    apply mul_left_cancel₀ hx0
    calc
      ψ (Reconstruction.x (k := k)) *
          ψ (Reconstruction.y (k := k)) =
          ψ (Reconstruction.q (k := k)) + 1 := by
            rw [← ψ.map_mul, ← ψ.map_one, ← ψ.map_add]
            exact congrArg ψ.toFun
              (Reconstruction.xy_eq_q_add_one (k := k))
      _ = f.1.hom sourceq + 1 := by rw [hq]
      _ = f.1.hom sourceX * f.1.hom sourceY := by
        simpa using (congrArg f.1.hom source_xy_eq_q_add_one).symm
      _ = ψ (Reconstruction.x (k := k)) * f.1.hom sourceY := by rw [hx]
  apply Subtype.ext
  apply CommRingCat.hom_ext
  apply MvPolynomial.ringHom_ext
  · intro a
    have hleft := compatible_commutes
      (functionFieldEmbeddingToCompatibleAlgHom φ)
      (MvPolynomial.C a)
    have hright := compatible_commutes f (MvPolynomial.C a)
    simpa [coordinateRingHom, coordinateAlgHom] using hleft.trans hright.symm
  · intro i
    fin_cases i
    · change ψ (Reconstruction.x (k := k)) = f.1.hom sourceX
      exact hx
    · change ψ (Reconstruction.y (k := k)) = f.1.hom sourceY
      exact hy

private theorem lift_restrict_eq
    (hirr : Irreducible (FieldExtension.cubic (k := k)))
    (φ : SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :
    compatibleAlgHomToFunctionFieldEmbedding hirr
        (functionFieldEmbeddingToCompatibleAlgHom φ) = φ := by
  apply hiddenPowerBasis.algHom_ext
  change
    hiddenPowerBasis.lift
        ((functionFieldEmbeddingToCompatibleAlgHom φ).1.hom sourcew) _
        hiddenPowerBasis.gen =
      φ hiddenPowerBasis.gen
  rw [hiddenPowerBasis.lift_gen, hiddenPowerBasis_gen]
  rfl

noncomputable def compatibleAlgHomFunctionFieldEmbeddingEquiv
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    CompatibleCommRingMap ≃
      (SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) where
  toFun := compatibleAlgHomToFunctionFieldEmbedding hirr
  invFun := functionFieldEmbeddingToCompatibleAlgHom
  left_inv := restrict_lift_eq hirr
  right_inv := lift_restrict_eq hirr

noncomputable def geometricFiberPointFunctionFieldEmbeddingEquiv
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    GeometricGenericFiberPoint ≃
      (SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :=
  geometricFiberPointCompatibleCommRingMapEquiv.trans
    (compatibleAlgHomFunctionFieldEmbeddingEquiv hirr)

theorem embedding_natCard_eq_three
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Nat.card
        (SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) =
      3 := by
  calc
    Nat.card
        (SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) =
        hiddenPowerBasis.dim := by
      exact AlgHom.natCard_of_powerBasis hiddenPowerBasis
        (by
          rw [hiddenPowerBasis_gen]
          exact DegreeFromIrreducible.hidden_isSeparable (k := k) hirr)
        (IsAlgClosed.splits _)
    _ = Module.finrank TargetFunctionField SourceFunctionField :=
      hiddenPowerBasis.finrank.symm
    _ = 3 := by
      change Module.finrank
        (DegreeFromIrreducible.E (k := k))
        (DegreeFromIrreducible.L (k := k)) = 3
      exact DegreeFromIrreducible.finrank_eq_three (k := k) hirr

theorem geometricFiberPoint_natCard_eq_three
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Nat.card GeometricGenericFiberPoint = 3 := by
  rw [Nat.card_congr (geometricFiberPointFunctionFieldEmbeddingEquiv hirr)]
  exact embedding_natCard_eq_three hirr

noncomputable def geometricFiberPointFunctionFieldEmbeddingEquiv_actual :
    GeometricGenericFiberPoint ≃
      (SourceFunctionField →ₐ[TargetFunctionField] GeometricClosure) :=
  geometricFiberPointFunctionFieldEmbeddingEquiv
    (ActualIrreducibility.cubic_irreducible (k := k))

theorem geometricFiberPoint_natCard_eq_three_actual :
    Nat.card GeometricGenericFiberPoint = 3 :=
  geometricFiberPoint_natCard_eq_three
    (ActualIrreducibility.cubic_irreducible (k := k))

end

end DimensionTwoCounterexample.Final.GeometricBridge
