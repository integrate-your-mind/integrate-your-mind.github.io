import DimensionTwoCounterexample.GenericCertificate

/-!
# Fraction-field reconstruction and denominator closure

This module lifts the polynomial certificate to the rational function field and
states the divisions used in the source proof only after proving every
denominator nonzero.
-/

namespace DimensionTwoCounterexample.Reconstruction

open MvPolynomial

noncomputable section

variable {k : Type*} [Field k] [CharP k 2]

abbrev R := Generic.Poly2 (k := k)
abbrev L := FractionRing (R (k := k))

def includePolynomial : R (k := k) →+* L (k := k) :=
  algebraMap (R (k := k)) (L (k := k))

def x : L (k := k) := includePolynomial Generic.x
def y : L (k := k) := includePolynomial Generic.y
def P : L (k := k) := includePolynomial Generic.P
def Q : L (k := k) := includePolynomial Generic.Q
def q : L (k := k) := includePolynomial Generic.q
def u : L (k := k) := includePolynomial Generic.u
def w : L (k := k) := includePolynomial Generic.w

theorem includePolynomial_injective :
    Function.Injective (includePolynomial (k := k)) :=
  IsFractionRing.injective (R (k := k)) (L (k := k))

private theorem include_ne_zero {f : R (k := k)} (hf : f ≠ 0) :
    includePolynomial (k := k) f ≠ 0 := by
  intro h
  apply hf
  apply includePolynomial_injective (k := k)
  simpa [includePolynomial] using h

theorem x_ne_zero : x (k := k) ≠ 0 :=
  include_ne_zero Generic.x_ne_zero

theorem P_ne_zero : P (k := k) ≠ 0 :=
  include_ne_zero Generic.P_ne_zero

theorem Q_ne_zero : Q (k := k) ≠ 0 :=
  include_ne_zero Generic.Q_ne_zero

theorem q_ne_zero : q (k := k) ≠ 0 :=
  include_ne_zero Generic.q_ne_zero

theorem u_ne_zero : u (k := k) ≠ 0 :=
  include_ne_zero Generic.u_ne_zero

theorem w_ne_zero : w (k := k) ≠ 0 :=
  include_ne_zero Generic.w_ne_zero

theorem x_sq_mul_w_ne_zero : x (k := k) ^ 2 * w ≠ 0 :=
  mul_ne_zero (pow_ne_zero 2 x_ne_zero) w_ne_zero

theorem recovery_x_mapped : x (k := k) * Q = 1 + w := by
  simpa [x, Q, w, includePolynomial] using
    congrArg (includePolynomial (k := k)) (Generic.recovery_x (k := k))

theorem recovery_q_mapped : P (k := k) ^ 2 = x ^ 2 * q * w := by
  simpa [P, x, q, w, includePolynomial] using
    congrArg (includePolynomial (k := k)) (Generic.recovery_q (k := k))

theorem cubic_root_mapped :
    w (k := k) ^ 3 + w ^ 2 + (P * Q + P ^ 3) * w + P ^ 3 = 0 := by
  simpa [P, Q, w, includePolynomial] using
    congrArg (includePolynomial (k := k)) (Generic.cubic_root (k := k))

theorem cubic_derivative_at_w_mapped :
    w (k := k) ^ 2 + P * Q + P ^ 3 = q * u := by
  simpa [P, Q, q, u, w, includePolynomial] using
    congrArg (includePolynomial (k := k))
      (Generic.cubic_derivative_at_w (k := k))

theorem q_definition_mapped : q (k := k) = 1 + x * y := by
  simp [q, x, y, includePolynomial, Generic.q]

theorem recover_x : x (k := k) = (w + 1) / Q := by
  apply (eq_div_iff Q_ne_zero).2
  simpa [add_comm] using recovery_x_mapped (k := k)

theorem recover_q : q (k := k) = P ^ 2 / (x ^ 2 * w) := by
  apply (eq_div_iff x_sq_mul_w_ne_zero).2
  calc
    q * (x ^ 2 * w) = x ^ 2 * q * w := by ring
    _ = P ^ 2 := (recovery_q_mapped (k := k)).symm

theorem xy_eq_q_add_one : x (k := k) * y = q + 1 := by
  calc
    x * y = (1 : L (k := k)) + (1 + x * y) :=
      (CharTwo.add_cancel_left (1 : L (k := k)) (x * y)).symm
    _ = (1 : L (k := k)) + q := by rw [← q_definition_mapped]
    _ = q + (1 : L (k := k)) := add_comm _ _

theorem recover_y : y (k := k) = (q + 1) / x := by
  apply (eq_div_iff x_ne_zero).2
  simpa [mul_comm] using xy_eq_q_add_one (k := k)

end

end DimensionTwoCounterexample.Reconstruction
