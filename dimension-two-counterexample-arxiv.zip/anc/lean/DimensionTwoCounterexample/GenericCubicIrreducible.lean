import Mathlib

/-!
# Generic cubic irreducibility interface

For a field `K`, put `A = K[Q]` and `F = Frac(A)`.  This file fixes the
polynomial used in the function-field argument:

`T^3 + T^2 + (p*Q + p^3)*T + p^3`.

The no-root proof uses the rational-root theorem.  A root in `F` of this monic
polynomial is the image of a polynomial `y : A` dividing the constant
coefficient `p^3`.  If `p ≠ 0`, that coefficient is a unit, so `y` is constant.
The coefficient of `Q` in the root equation then forces that constant to be
zero, contradicting the nonzero constant term.

The declarations below contain no `sorry`, `admit`, axioms, or unsafe code.
-/

namespace DimensionTwoCounterexample.GenericCubic

open Polynomial

noncomputable section

variable {K : Type*} [Field K]

abbrev A := Polynomial K
abbrev F := FractionRing (A (K := K))

def cubicOverA (p : K) : Polynomial (A (K := K)) :=
  X ^ 3 + X ^ 2 +
    C (C p * (X : Polynomial K) + C (p ^ 3)) * X +
    C (C (p ^ 3))

def cubicOverF (p : K) : Polynomial (F (K := K)) :=
  Polynomial.map (algebraMap (A (K := K)) (F (K := K))) (cubicOverA p)

theorem cubicOverA_monic (p : K) : (cubicOverA p).Monic := by
  simp only [cubicOverA]
  monicity <;> norm_num

theorem cubicOverF_monic (p : K) : (cubicOverF p).Monic := by
  exact Polynomial.Monic.map
    (algebraMap (A (K := K)) (F (K := K)))
    (cubicOverA_monic (K := K) p)

theorem cubicOverA_natDegree (p : K) :
    (cubicOverA (K := K) p).natDegree = 3 := by
  simp only [cubicOverA]
  compute_degree <;> norm_num

theorem cubicOverF_natDegree (p : K) :
    (cubicOverF (K := K) p).natDegree = 3 := by
  calc
    (cubicOverF (K := K) p).natDegree =
        (cubicOverA (K := K) p).natDegree := by
      exact (cubicOverA_monic (K := K) p).natDegree_map
        (algebraMap (A (K := K)) (F (K := K)))
    _ = 3 := cubicOverA_natDegree (K := K) p

theorem cubicOverA_coeff_zero (p : K) :
    (cubicOverA (K := K) p).coeff 0 = C (p ^ 3) := by
  rw [Polynomial.coeff_zero_eq_eval_zero]
  simp [cubicOverA]

theorem cubicOverF_not_isRoot
    (p : K) (hp : p ≠ 0) (z : F (K := K)) :
    ¬ (cubicOverF (K := K) p).IsRoot z := by
  intro hz
  have hz' : aeval z (cubicOverA (K := K) p) = 0 := by
    simpa only [aeval_def, eval₂_eq_eval_map, cubicOverF, IsRoot] using hz
  obtain ⟨y, hzy, hydiv⟩ :=
    exists_integer_of_is_root_of_monic
      (cubicOverA_monic (K := K) p) hz'
  have hunit : IsUnit (C (p ^ 3) : A (K := K)) := by
    simpa [hp]
  have hyunit : IsUnit y := by
    apply isUnit_of_dvd_unit
    · simpa only [cubicOverA_coeff_zero] using hydiv
    · exact hunit
  obtain ⟨a, _, hay⟩ := Polynomial.isUnit_iff.mp hyunit
  have hyroot : (cubicOverA (K := K) p).IsRoot y := by
    have hmapped :
        ((cubicOverA (K := K) p).map
          (algebraMap (A (K := K)) (F (K := K)))).IsRoot
            (algebraMap (A (K := K)) (F (K := K)) y) := by
      simpa only [cubicOverF, ← hzy] using hz
    exact hmapped.of_map
      (IsFractionRing.injective (A (K := K)) (F (K := K)))
  rw [← hay, Polynomial.IsRoot, cubicOverA] at hyroot
  simp only [eval_add, eval_pow, eval_X, eval_C, eval_mul] at hyroot
  have hcoeff := congrArg (fun f : Polynomial K => f.coeff 1) hyroot
  have hCa3 : (C a : Polynomial K) ^ 3 = C (a ^ 3) := by
    rw [Polynomial.C_pow]
  have hCa2 : (C a : Polynomial K) ^ 2 = C (a ^ 2) := by
    rw [Polynomial.C_pow]
  rw [hCa3, hCa2] at hcoeff
  simp only [Polynomial.coeff_add, Polynomial.coeff_mul_C,
    Polynomial.coeff_C_mul_X, Polynomial.coeff_C, Polynomial.coeff_zero,
    if_pos, if_false, one_ne_zero, zero_add, add_zero, mul_zero, zero_mul,
    mul_one] at hcoeff
  have ha : a = 0 := (mul_eq_zero.mp hcoeff).resolve_left hp
  rw [ha] at hyroot
  simpa [hp] using hyroot

theorem cubicOverF_irreducible (p : K) (hp : p ≠ 0) :
    Irreducible (cubicOverF (K := K) p) := by
  apply Polynomial.irreducible_of_degree_le_three_of_not_isRoot
  · rw [Finset.mem_Icc, cubicOverF_natDegree]
    omega
  · exact cubicOverF_not_isRoot (K := K) p hp

/-
The exact Mathlib cubic criterion is the final kernel step once the two degree
bounds and the no-root statement have been supplied.  Keeping the bounds as
arguments makes this helper independent of fragile simplifier behavior for
nested polynomial coefficients.
-/
theorem cubicOverF_irreducible_of_no_root
    (p : K)
    (hdeg2 : 2 ≤ (cubicOverF (K := K) p).natDegree)
    (hdeg3 : (cubicOverF (K := K) p).natDegree ≤ 3)
    (hroot : ∀ z : F (K := K),
      ¬ (cubicOverF (K := K) p).IsRoot z) :
    Irreducible (cubicOverF (K := K) p) := by
  apply Polynomial.irreducible_of_degree_le_three_of_not_isRoot
  · rw [Finset.mem_Icc]
    exact ⟨by omega, hdeg3⟩
  · exact hroot

/-
The theorem `cubicOverF_irreducible` is the unconditional interface needed by
the function-field argument: its only hypothesis is `p ≠ 0`.  The older helper
above remains useful when a caller already has degree and no-root facts in a
different presentation of the same cubic.
-/

end

end DimensionTwoCounterexample.GenericCubic
