import DimensionTwoCounterexample.Reconstruction

/-!
# Generic function-field layer

This file records the part of the function-field argument which does not use
irreducibility of the cubic.  The base field is only assumed to be a field of
characteristic two.  In particular, no algebraic-closure or geometric-degree
claim is made here.
-/

namespace DimensionTwoCounterexample.FieldExtension

open MvPolynomial

noncomputable section

variable {k : Type*} [Field k] [CharP k 2]

abbrev R := Generic.Poly2 (k := k)
abbrev L := FractionRing (R (k := k))

def source : Fin 2 → L (k := k) :=
  ![Reconstruction.x (k := k), Reconstruction.y (k := k)]

def target : Fin 2 → L (k := k) :=
  ![Reconstruction.P (k := k), Reconstruction.Q (k := k)]

abbrev E : IntermediateField k (L (k := k)) :=
  IntermediateField.adjoin k (Set.range (target (k := k)))

def targetInE (i : Fin 2) : E (k := k) :=
  ⟨target (k := k) i,
    IntermediateField.mem_adjoin_of_mem k (Set.mem_range_self i)⟩

def cubic : Polynomial (E (k := k)) :=
  Polynomial.X ^ 3 + Polynomial.X ^ 2 +
    Polynomial.C
        (targetInE (k := k) 0 * targetInE (k := k) 1 +
          targetInE (k := k) 0 ^ 3) * Polynomial.X +
      Polynomial.C (targetInE (k := k) 0 ^ 3)

theorem targetInE_apply_zero :
    (targetInE (k := k) 0 : L (k := k)) = Reconstruction.P (k := k) := by
  rfl

theorem targetInE_apply_one :
    (targetInE (k := k) 1 : L (k := k)) = Reconstruction.Q (k := k) := by
  rfl

theorem cubic_monic : (cubic (k := k)).Monic := by
  simp only [cubic]
  monicity <;> norm_num

theorem cubic_root :
    Polynomial.aeval (Reconstruction.w (k := k)) (cubic (k := k)) = 0 := by
  rw [Polynomial.aeval_def]
  simp only [cubic, Polynomial.eval₂_add, Polynomial.eval₂_pow,
    Polynomial.eval₂_mul, Polynomial.eval₂_X, Polynomial.eval₂_C]
  change
    Reconstruction.w (k := k) ^ 3 + Reconstruction.w (k := k) ^ 2 +
      (Reconstruction.P (k := k) * Reconstruction.Q (k := k) +
        Reconstruction.P (k := k) ^ 3) * Reconstruction.w (k := k) +
      Reconstruction.P (k := k) ^ 3 = 0
  exact Reconstruction.cubic_root_mapped (k := k)

private theorem source_polynomial_mem_adjoin :
    ∀ f : R (k := k),
      Reconstruction.includePolynomial (k := k) f ∈
        IntermediateField.adjoin k (Set.range (source (k := k))) := by
  intro f
  induction f using MvPolynomial.induction_on with
  | C a =>
      change algebraMap k (L (k := k)) a ∈
        IntermediateField.adjoin k (Set.range (source (k := k)))
      exact (IntermediateField.adjoin k
        (Set.range (source (k := k)))).algebraMap_mem a
  | add f g hf hg =>
      rw [map_add]
      exact (IntermediateField.adjoin k
        (Set.range (source (k := k)))).add_mem hf hg
  | mul_X f i hf =>
      have hi :
          Reconstruction.includePolynomial (k := k) (X i) ∈
            IntermediateField.adjoin k (Set.range (source (k := k))) := by
        fin_cases i
        · change Reconstruction.x (k := k) ∈
            IntermediateField.adjoin k (Set.range (source (k := k)))
          exact IntermediateField.mem_adjoin_of_mem k
            (Set.mem_range_self (0 : Fin 2))
        · change Reconstruction.y (k := k) ∈
            IntermediateField.adjoin k (Set.range (source (k := k)))
          exact IntermediateField.mem_adjoin_of_mem k
            (Set.mem_range_self (1 : Fin 2))
      rw [map_mul]
      exact (IntermediateField.adjoin k
        (Set.range (source (k := k)))).mul_mem hf hi

theorem source_adjoin_eq_top :
    IntermediateField.adjoin k (Set.range (source (k := k))) = ⊤ := by
  apply top_unique
  intro z hz
  rcases IsFractionRing.div_surjective (A := R (k := k)) z with
    ⟨a, b, hb, hab⟩
  rw [← hab]
  exact (IntermediateField.adjoin k (Set.range (source (k := k)))).div_mem
    (source_polynomial_mem_adjoin a) (source_polynomial_mem_adjoin b)

theorem source_adjoin_eq_top_over_E :
    IntermediateField.adjoin (E (k := k)) (Set.range (source (k := k))) = ⊤ :=
  IntermediateField.adjoin_eq_top_of_adjoin_eq_top k (source_adjoin_eq_top (k := k))

private theorem target_mem_adjoin (i : Fin 2) :
    target (k := k) i ∈ E (k := k) :=
  IntermediateField.mem_adjoin_of_mem k (Set.mem_range_self i)

private theorem hidden_mem_adjoin_simple :
    Reconstruction.w (k := k) ∈
      IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} :=
  IntermediateField.mem_adjoin_of_mem (E (k := k)) (Set.mem_singleton _)

theorem source_x_mem_adjoin_simple :
    Reconstruction.x (k := k) ∈
      IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} := by
  let K := IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)}
  have hQ : Reconstruction.Q (k := k) ∈ K := by
    change algebraMap (E (k := k)) (L (k := k))
      ⟨Reconstruction.Q (k := k), target_mem_adjoin (k := k) 1⟩ ∈ K
    exact K.algebraMap_mem _
  have hw : Reconstruction.w (k := k) ∈ K := hidden_mem_adjoin_simple (k := k)
  rw [Reconstruction.recover_x (k := k)]
  exact K.div_mem (K.add_mem hw K.one_mem) hQ

theorem source_q_mem_adjoin_simple :
    Reconstruction.q (k := k) ∈
      IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} := by
  let K := IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)}
  have hP : Reconstruction.P (k := k) ∈ K := by
    change algebraMap (E (k := k)) (L (k := k))
      ⟨Reconstruction.P (k := k), target_mem_adjoin (k := k) 0⟩ ∈ K
    exact K.algebraMap_mem _
  have hw : Reconstruction.w (k := k) ∈ K := hidden_mem_adjoin_simple (k := k)
  have hx : Reconstruction.x (k := k) ∈ K := source_x_mem_adjoin_simple (k := k)
  rw [Reconstruction.recover_q (k := k)]
  exact K.div_mem (K.pow_mem hP 2) (K.mul_mem (K.pow_mem hx 2) hw)

theorem source_y_mem_adjoin_simple :
    Reconstruction.y (k := k) ∈
      IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} := by
  let K := IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)}
  have hq : Reconstruction.q (k := k) ∈ K := source_q_mem_adjoin_simple (k := k)
  have hx : Reconstruction.x (k := k) ∈ K := source_x_mem_adjoin_simple (k := k)
  rw [Reconstruction.recover_y (k := k)]
  exact K.div_mem (K.add_mem hq K.one_mem) hx

theorem adjoin_hidden_eq_top :
    IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} = ⊤ := by
  apply top_unique
  intro z hz
  have hgen :
      IntermediateField.adjoin (E (k := k)) (Set.range (source (k := k))) ≤
        IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} := by
    refine IntermediateField.adjoin_le_iff.mpr ?_
    intro x hx
    rcases hx with ⟨i, rfl⟩
    fin_cases i
    · exact source_x_mem_adjoin_simple (k := k)
    · exact source_y_mem_adjoin_simple (k := k)
  have htop := source_adjoin_eq_top_over_E (k := k)
  have : (⊤ : IntermediateField E (L (k := k))) ≤
      IntermediateField.adjoin (E (k := k)) {Reconstruction.w (k := k)} := by
    rw [← htop]
    exact hgen
  exact this hz

theorem algebraic_over_E :
    Algebra.IsAlgebraic (E (k := k)) (L (k := k)) := by
  have hw : IsIntegral (E (k := k)) (Reconstruction.w (k := k)) := by
    exact ⟨cubic (k := k), cubic_monic (k := k), cubic_root (k := k)⟩
  have hK : Algebra.IsAlgebraic (E (k := k))
      (IntermediateField.adjoin (E (k := k))
        {Reconstruction.w (k := k)}) :=
    IntermediateField.isAlgebraic_adjoin_simple hw
  rw [adjoin_hidden_eq_top (k := k)] at hK
  letI : Algebra.IsAlgebraic (E (k := k))
      (⊤ : IntermediateField (E (k := k)) (L (k := k))) := hK
  exact IntermediateField.topEquiv.isAlgebraic

theorem algebraic_independent_target :
    AlgebraicIndependent k (target (k := k)) := by
  letI : Algebra.IsAlgebraic (E (k := k)) (L (k := k)) := algebraic_over_E (k := k)
  have hAlg :
      Algebra.IsAlgebraic
        (Algebra.adjoin k (Set.range (target (k := k)))) (L (k := k)) :=
    (IntermediateField.isAlgebraic_adjoin_iff_top
      (F := k) (E := L (k := k)) (S := L (k := k))
      (s := Set.range (target (k := k)))).mp inferInstance
  letI : Algebra.IsAlgebraic
      (Algebra.adjoin k (Set.range (target (k := k)))) (L (k := k)) := hAlg
  have hX : AlgebraicIndependent k
      (fun i : Fin 2 =>
        algebraMap (R (k := k)) (L (k := k)) (X i)) := by
    simpa only [Function.comp_apply] using
      (MvPolynomial.algebraicIndependent_X (Fin 2) k).map'
        (f := IsScalarTower.toAlgHom k (R (k := k)) (L (k := k)))
        (Reconstruction.includePolynomial_injective (k := k))
  exact
    (Algebra.IsAlgebraic.isTranscendenceBasis_of_lift_le_trdeg_of_finite
      k (target (k := k)) hX.lift_cardinalMk_le_trdeg).1

end

end DimensionTwoCounterexample.FieldExtension
