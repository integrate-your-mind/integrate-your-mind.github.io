import Mathlib

/-!
# Uniform characteristic-two certificate

This file states the computational certificate over an arbitrary field of
characteristic two.  The final counterexample specializes `k` to
`AlgebraicClosure (ZMod 2)`.

The declarations contain no placeholders, but they are not ledgered as
kernel-checked until the exact pinned toolchain compiles this file.
-/

namespace DimensionTwoCounterexample.Generic

open MvPolynomial

noncomputable section

variable {k : Type*} [Field k] [CharP k 2]

abbrev Poly2 := MvPolynomial (Fin 2) k

def x : Poly2 (k := k) := X 0
def y : Poly2 (k := k) := X 1

def P : Poly2 (k := k) :=
  x + x ^ 2 * y + x ^ 4 + x ^ 6 * y ^ 2

def Q : Poly2 (k := k) :=
  y + x ^ 5 + x ^ 6 * y + x ^ 7 * y ^ 2 + x ^ 8 * y ^ 3

def q : Poly2 (k := k) := 1 + x * y
def u : Poly2 (k := k) := 1 + x ^ 3 * q
def w : Poly2 (k := k) := q * u ^ 2

def evalAt (a b : k) : Poly2 (k := k) →+* k :=
  eval ![a, b]

private lemma ofNat_eq_mod_two_poly (n : ℕ) [n.AtLeastTwo] :
    (OfNat.ofNat n : Poly2 (k := k)) = (n % 2 : ℕ) := by
  rw [← Nat.cast_ofNat]
  exact CharP.cast_eq_mod (Poly2 (k := k)) 2 n

private lemma ofNat_eq_mod_two_field (n : ℕ) [n.AtLeastTwo] :
    (OfNat.ofNat n : k) = (n % 2 : ℕ) := by
  rw [← Nat.cast_ofNat]
  exact CharP.cast_eq_mod k 2 n

theorem P_compact : P (k := k) = x * q * u := by
  simp only [P, q, u]
  ring_nf
  simp [CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem Q_compact : Q (k := k) = y + x ^ 5 * q ^ 3 := by
  simp only [Q, q]
  ring_nf
  simp [ofNat_eq_mod_two_poly]

theorem x_ne_zero : x (k := k) ≠ 0 := by
  intro hx
  have hx' := congrArg (evalAt (k := k) 1 0) hx
  simpa [evalAt, x] using hx'

theorem q_ne_zero : q (k := k) ≠ 0 := by
  intro hq
  have hq' := congrArg (evalAt (k := k) 0 0) hq
  simpa [evalAt, q, x, y] using hq'

theorem u_ne_zero : u (k := k) ≠ 0 := by
  intro hu
  have hu' := congrArg (evalAt (k := k) 0 0) hu
  simpa [evalAt, u, q, x, y] using hu'

theorem w_ne_zero : w (k := k) ≠ 0 := by
  intro hw
  have hw' := congrArg (evalAt (k := k) 0 0) hw
  simpa [evalAt, w, u, q, x, y] using hw'

theorem P_ne_zero : P (k := k) ≠ 0 := by
  rw [P_compact]
  exact mul_ne_zero (mul_ne_zero x_ne_zero q_ne_zero) u_ne_zero

theorem Q_ne_zero : Q (k := k) ≠ 0 := by
  intro hQ
  have hQ' := congrArg (evalAt (k := k) 0 1) hQ
  simpa [evalAt, Q, x, y] using hQ'

theorem pderiv_x_P : pderiv 0 (P (k := k)) = 1 := by
  simp [P, x, y, pderiv]
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem pderiv_y_P : pderiv 1 (P (k := k)) = x ^ 2 := by
  simp [P, x, y, pderiv]
  simp [CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem pderiv_x_Q :
    pderiv 0 (Q (k := k)) = x ^ 4 + x ^ 6 * y ^ 2 := by
  simp [Q, x, y, pderiv]
  simp [ofNat_eq_mod_two_poly]
  ring_nf

theorem pderiv_y_Q :
    pderiv 1 (Q (k := k)) = 1 + x ^ 6 + x ^ 8 * y ^ 2 := by
  simp [Q, x, y, pderiv]
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem jacobian_det :
    pderiv 0 (P (k := k)) * pderiv 1 Q -
      pderiv 1 P * pderiv 0 Q = 1 := by
  rw [pderiv_x_P, pderiv_y_P, pderiv_x_Q, pderiv_y_Q]
  ring_nf

def Pval (a b : k) : k :=
  a + a ^ 2 * b + a ^ 4 + a ^ 6 * b ^ 2

def Qval (a b : k) : k :=
  b + a ^ 5 + a ^ 6 * b + a ^ 7 * b ^ 2 + a ^ 8 * b ^ 3

theorem collision_01_10 :
    (Pval (k := k) 0 1, Qval (k := k) 0 1) =
      (Pval (k := k) 1 0, Qval (k := k) 1 0) := by
  simp only [Pval, Qval]
  ring_nf
  simp [ofNat_eq_mod_two_field]

theorem collision_01_11 :
    (Pval (k := k) 0 1, Qval (k := k) 0 1) =
      (Pval (k := k) 1 1, Qval (k := k) 1 1) := by
  simp only [Pval, Qval]
  ring_nf
  simp [ofNat_eq_mod_two_field]

theorem collision_value :
    (Pval (k := k) 0 1, Qval (k := k) 0 1) = (0, 1) := by
  simp [Pval, Qval]

theorem origin_value :
    (Pval (k := k) 0 0, Qval (k := k) 0 0) = (0, 0) := by
  simp [Pval, Qval]

theorem recovery_x :
    x (k := k) * Q (k := k) = 1 + w (k := k) := by
  simp only [Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem recovery_q :
    P (k := k) ^ 2 = x (k := k) ^ 2 * q (k := k) * w (k := k) := by
  rw [P_compact]
  simp only [w]
  ring_nf

theorem cubic_root :
    w (k := k) ^ 3 + w ^ 2 + (P * Q + P ^ 3) * w + P ^ 3 = 0 := by
  simp only [P, Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem cubic_derivative_at_w :
    w (k := k) ^ 2 + P * Q + P ^ 3 = q * u := by
  simp only [P, Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

theorem elimination_cubic :
    Q (k := k) ^ 2 * x ^ 3 + (P ^ 3 + P * Q + 1) * x + P = 0 := by
  simp only [P, Q]
  ring_nf
  simp [ofNat_eq_mod_two_poly,
    CharTwo.two_eq_zero (R := Poly2 (k := k))]

end

end DimensionTwoCounterexample.Generic
