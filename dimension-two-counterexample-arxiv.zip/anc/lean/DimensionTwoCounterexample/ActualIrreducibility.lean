import DimensionTwoCounterexample.FieldExtension
import DimensionTwoCounterexample.GenericCubicIrreducible

/-!
# Actual irreducibility transport: source-level boundary

This file records the kernel-checkable beginning of the requested transport.
The generic cubic lives over the fraction field of `Polynomial K`, where
`K = k⟮P⟯`.  The scoped `IntermediateField.transcendental_adjoin_iff` bridge
upgrades the polynomial-adjoin statement to this field base.

No declaration in this file uses `sorry`, `admit`, an axiom, or unsafe code.
These declarations remain source-level evidence until the exact pinned Lean
kernel accepts them.
-/

namespace DimensionTwoCounterexample.ActualIrreducibility

noncomputable section

open MvPolynomial
open scoped IntermediateField.algebraAdjoinAdjoin

variable {k : Type*} [Field k] [CharP k 2]

abbrev R := FieldExtension.R (k := k)
abbrev L := FieldExtension.L (k := k)
abbrev K := IntermediateField.adjoin k ({Reconstruction.P (k := k)} : Set (L (k := k)))
abbrev A := Algebra.adjoin k ({Reconstruction.P (k := k)} : Set (L (k := k)))

/- The singleton/PUnit polynomial equivalence requested by the transport
   construction.  Its orientation is `MvPolynomial PUnit K ≃ₐ[K] Polynomial K`.
   This is an exact Mathlib equivalence, not a replacement theorem. -/
def pUnitPolynomialAlgEquiv :
    MvPolynomial PUnit.{1} (K (k := k)) ≃ₐ[K (k := k)] Polynomial (K (k := k)) :=
  MvPolynomial.pUnitAlgEquiv (K (k := k))

set_option maxHeartbeats 1000000 in
set_option synthInstance.maxHeartbeats 1000000 in
def pUnitFractionAlgEquiv :
    FractionRing (MvPolynomial PUnit.{1} (K (k := k))) ≃ₐ[K (k := k)]
      FractionRing (Polynomial (K (k := k))) :=
  IsFractionRing.algEquivOfAlgEquiv
    (R := K (k := k))
    (A := MvPolynomial PUnit.{1} (K (k := k)))
    (B := Polynomial (K (k := k)))
    (K := FractionRing (MvPolynomial PUnit.{1} (K (k := k))))
    (L := FractionRing (Polynomial (K (k := k))))
    (pUnitPolynomialAlgEquiv (k := k))

/- `transcendental_adjoin` is applied exactly to the omitted second coordinate
   of the algebraically independent target family. -/
theorem q_transcendental_over_polynomial_adjoin :
    Transcendental (A (k := k)) (Reconstruction.Q (k := k)) := by
  have h :=
    (FieldExtension.algebraic_independent_target (k := k)).transcendental_adjoin
      (s := ({(0 : Fin 2)} : Set (Fin 2))) (i := (1 : Fin 2)) (by simp)
  have hs : FieldExtension.target (k := k) ''
      ({(0 : Fin 2)} : Set (Fin 2)) =
      ({Reconstruction.P (k := k)} : Set (L (k := k))) := by
    ext z
    constructor
    · rintro ⟨i, hi, rfl⟩
      have hi0 : i = 0 := Set.mem_singleton_iff.mp hi
      subst i
      simp [FieldExtension.target]
    · intro hz
      have hz' : z = Reconstruction.P (k := k) := Set.mem_singleton_iff.mp hz
      subst z
      exact ⟨0, Set.mem_singleton 0, by simp [FieldExtension.target]⟩
  rw [hs] at h
  exact h

/- The scoped `IntermediateField` localization theorem is the missing
   denominator-clearing bridge: it identifies transcendence over the field
   adjoin with transcendence over the polynomial adjoin. -/
theorem q_transcendental_over_K :
    Transcendental (K (k := k)) (Reconstruction.Q (k := k)) := by
  exact (IntermediateField.transcendental_adjoin_iff
    (F := k) (E := L (k := k))
    (S := L (k := k))
    (s := ({Reconstruction.P (k := k)} : Set (L (k := k))))
    (x := Reconstruction.Q (k := k))).2
    (q_transcendental_over_polynomial_adjoin (k := k))

theorem q_pUnit_algebraicIndependent :
    AlgebraicIndependent (K (k := k))
      (fun _ : PUnit.{1} => Reconstruction.Q (k := k)) :=
  (algebraicIndependent_unique_type_iff (ι := PUnit.{1})
    (R := K (k := k)) (A := L (k := k))).2
    (q_transcendental_over_K (k := k))

def q_aevalEquivField :
    FractionRing (MvPolynomial PUnit.{1} (K (k := k))) ≃ₐ[K (k := k)]
      ↥(IntermediateField.adjoin (K (k := k))
        (Set.range (fun _ : PUnit.{1} => Reconstruction.Q (k := k)))) :=
  (q_pUnit_algebraicIndependent (k := k)).aevalEquivField

abbrev KQ := IntermediateField.adjoin (K (k := k))
  (Set.range (fun _ : PUnit.{1} => Reconstruction.Q (k := k)))

def q_aevalEquivField_target :
    FractionRing (MvPolynomial PUnit.{1} (K (k := k))) ≃ₐ[K (k := k)]
      (KQ (k := k)) :=
  q_aevalEquivField (k := k)

def pInK : K (k := k) :=
  ⟨Reconstruction.P (k := k),
    IntermediateField.mem_adjoin_of_mem k (Set.mem_singleton _)
  ⟩

theorem pInK_ne_zero : pInK (k := k) ≠ 0 := by
  intro h
  apply Reconstruction.P_ne_zero (k := k)
  exact congrArg Subtype.val h

def genericToKQAlgEquiv :
    FractionRing (Polynomial (K (k := k))) ≃ₐ[K (k := k)] (KQ (k := k)) :=
  (pUnitFractionAlgEquiv (k := k)).symm.trans (q_aevalEquivField (k := k))

theorem genericToKQAlgEquiv_C (a : K (k := k)) :
    genericToKQAlgEquiv (k := k)
        (algebraMap (Polynomial (K (k := k)))
          (FractionRing (Polynomial (K (k := k))))
          (Polynomial.C a)) =
      algebraMap (K (k := k)) (KQ (k := k)) a := by
  change genericToKQAlgEquiv (k := k)
      (algebraMap (K (k := k))
        (FractionRing (Polynomial (K (k := k)))) a) = _
  exact (genericToKQAlgEquiv (k := k)).commutes a

set_option maxHeartbeats 1200000 in
theorem genericToKQAlgEquiv_X :
    genericToKQAlgEquiv (k := k)
        (algebraMap (Polynomial (K (k := k)))
          (FractionRing (Polynomial (K (k := k))))
          (Polynomial.X : Polynomial (K (k := k)))) =
      ⟨Reconstruction.Q (k := k),
        IntermediateField.mem_adjoin_of_mem (K (k := k))
          (Set.mem_range_self PUnit.unit)⟩ := by
  simp only [genericToKQAlgEquiv, AlgEquiv.trans_apply, pUnitFractionAlgEquiv,
    IsFractionRing.algEquivOfAlgEquiv_symm,
    IsFractionRing.algEquivOfAlgEquiv_algebraMap,
    q_aevalEquivField]
  apply Subtype.ext
  rw [AlgebraicIndependent.aevalEquivField_algebraMap_apply_coe]
  simp [pUnitPolynomialAlgEquiv, aeval_def]

theorem irreducible_polynomial_mapEquiv
    {F S : Type*} [Field F] [Field S]
    (e : F ≃+* S) (f : Polynomial F)
    (hf : Irreducible f) :
    Irreducible (Polynomial.mapEquiv e f) := by
  exact (MulEquiv.irreducible_iff (Polynomial.mapEquiv e)).2 hf

def transportedGenericCubic : Polynomial (KQ (k := k)) :=
  Polynomial.mapEquiv (genericToKQAlgEquiv (k := k))
    (GenericCubic.cubicOverF (K := K (k := k)) (pInK (k := k)))

private theorem K_le_E : K (k := k) ≤ FieldExtension.E (k := k) := by
  refine IntermediateField.adjoin_le_iff.mpr ?_
  intro z hz
  have hz' : z = Reconstruction.P (k := k) := Set.mem_singleton_iff.mp hz
  subst z
  exact IntermediateField.mem_adjoin_of_mem k
    (Set.mem_range_self (0 : Fin 2))

private def E_over_K : IntermediateField (K (k := k)) (L (k := k)) :=
  { carrier := FieldExtension.E (k := k)
    zero_mem' := FieldExtension.E (k := k).zero_mem
    one_mem' := FieldExtension.E (k := k).one_mem
    add_mem' := FieldExtension.E (k := k).add_mem
    mul_mem' := FieldExtension.E (k := k).mul_mem
    inv_mem' := fun x hx => FieldExtension.E (k := k).inv_mem hx
    algebraMap_mem' := fun z => by
      change (z : L (k := k)) ∈ FieldExtension.E (k := k)
      exact K_le_E (k := k) z.property }

private theorem E_le_restrict_KQ : FieldExtension.E (k := k) ≤
    IntermediateField.restrictScalars k (KQ (k := k)) := by
  refine IntermediateField.adjoin_le_iff.mpr ?_
  intro z hz
  rcases hz with ⟨i, rfl⟩
  fin_cases i
  · simpa [pInK] using (KQ (k := k)).algebraMap_mem (pInK (k := k))
  · exact IntermediateField.mem_adjoin_of_mem (K (k := k))
      (Set.mem_range_self PUnit.unit)

private theorem KQ_eq_E_over_K : KQ (k := k) = E_over_K (k := k) := by
  apply le_antisymm
  · refine IntermediateField.adjoin_le_iff.mpr ?_
    intro z hz
    rcases hz with ⟨i, rfl⟩
    simpa [E_over_K] using
      (IntermediateField.mem_adjoin_of_mem k
        (Set.mem_range_self (1 : Fin 2)) :
        Reconstruction.Q (k := k) ∈ FieldExtension.E (k := k))
  · apply (IntermediateField.restrictScalars_le_iff k).mp
    intro z hz
    apply E_le_restrict_KQ (k := k)
    simpa [E_over_K] using hz

theorem KQ_restrictScalars_eq_E :
    IntermediateField.restrictScalars k (KQ (k := k)) = FieldExtension.E (k := k) := by
  rw [KQ_eq_E_over_K (k := k)]
  apply SetLike.coe_injective
  rfl

private def E_over_K_to_E : E_over_K (k := k) ≃+* FieldExtension.E (k := k) :=
  { toFun := fun z => ⟨z.1, by simpa [E_over_K] using z.2⟩
    invFun := fun z => ⟨z.1, by simpa [E_over_K] using z.2⟩
    left_inv := by intro z; rfl
    right_inv := by intro z; rfl
    map_add' := by intro x y; rfl
    map_mul' := by intro x y; rfl }

def KQ_to_E : KQ (k := k) ≃+* FieldExtension.E (k := k) :=
  (IntermediateField.equivOfEq (KQ_eq_E_over_K (k := k))).toRingEquiv.trans
    (E_over_K_to_E (k := k))

theorem KQ_to_E_p :
    KQ_to_E (k := k)
        (algebraMap (K (k := k)) (KQ (k := k)) (pInK (k := k))) =
      ⟨Reconstruction.P (k := k),
        IntermediateField.mem_adjoin_of_mem k
          (Set.mem_range_self (0 : Fin 2))⟩ := by
  rfl

theorem KQ_to_E_q :
    KQ_to_E (k := k)
        ⟨Reconstruction.Q (k := k),
          IntermediateField.mem_adjoin_of_mem (K (k := k))
            (Set.mem_range_self PUnit.unit)⟩ =
      ⟨Reconstruction.Q (k := k),
        IntermediateField.mem_adjoin_of_mem k
          (Set.mem_range_self (1 : Fin 2))⟩ := by
  rfl

theorem genericToKQAlgEquiv_A_C (a : K (k := k)) :
    genericToKQAlgEquiv (k := k)
        ((algebraMap (GenericCubic.A (K := K (k := k)))
          (GenericCubic.F (K := K (k := k))))
          (Polynomial.C a)) =
      algebraMap (K (k := k)) (KQ (k := k)) a := by
  change genericToKQAlgEquiv (k := k)
      (algebraMap (K (k := k))
        (FractionRing (Polynomial (K (k := k)))) a) = _
  exact (genericToKQAlgEquiv (k := k)).commutes a

theorem genericToKQAlgEquiv_A_X :
    genericToKQAlgEquiv (k := k)
        ((algebraMap (GenericCubic.A (K := K (k := k)))
          (GenericCubic.F (K := K (k := k))))
          (Polynomial.X : Polynomial (K (k := k)))) =
      ⟨Reconstruction.Q (k := k),
        IntermediateField.mem_adjoin_of_mem (K (k := k))
          (Set.mem_range_self PUnit.unit)⟩ := by
  change genericToKQAlgEquiv (k := k)
      (algebraMap (Polynomial (K (k := k)))
        (FractionRing (Polynomial (K (k := k)))) Polynomial.X) = _
  exact genericToKQAlgEquiv_X (k := k)

theorem KQ_to_E_genericTo_A_C :
    KQ_to_E (k := k)
        (genericToKQAlgEquiv (k := k)
          ((algebraMap (GenericCubic.A (K := K (k := k)))
            (GenericCubic.F (K := K (k := k))))
            (Polynomial.C (pInK (k := k))))) =
      ⟨Reconstruction.P (k := k),
        IntermediateField.mem_adjoin_of_mem k
          (Set.mem_range_self (0 : Fin 2))⟩ := by
  rw [genericToKQAlgEquiv_A_C (k := k) (pInK (k := k))]
  exact KQ_to_E_p (k := k)

theorem KQ_to_E_genericTo_A_X :
    KQ_to_E (k := k)
        (genericToKQAlgEquiv (k := k)
          ((algebraMap (GenericCubic.A (K := K (k := k)))
            (GenericCubic.F (K := K (k := k))))
            (Polynomial.X : Polynomial (K (k := k))))) =
      ⟨Reconstruction.Q (k := k),
        IntermediateField.mem_adjoin_of_mem k
          (Set.mem_range_self (1 : Fin 2))⟩ := by
  rw [genericToKQAlgEquiv_A_X (k := k)]
  exact KQ_to_E_q (k := k)

set_option maxHeartbeats 2000000 in
theorem transportedGenericCubic_irreducible :
    Irreducible (transportedGenericCubic (k := k)) := by
  exact irreducible_polynomial_mapEquiv
    (genericToKQAlgEquiv (k := k)).toRingEquiv
    (GenericCubic.cubicOverF (K := K (k := k)) (pInK (k := k)))
    (GenericCubic.cubicOverF_irreducible
      (K := K (k := k)) (pInK (k := k)) (pInK_ne_zero (k := k)))

def transportedGenericCubicToE : Polynomial (FieldExtension.E (k := k)) :=
  Polynomial.mapEquiv (KQ_to_E (k := k)) (transportedGenericCubic (k := k))

theorem transportedGenericCubicToE_irreducible :
    Irreducible (transportedGenericCubicToE (k := k)) :=
  irreducible_polynomial_mapEquiv (KQ_to_E (k := k))
    (transportedGenericCubic (k := k))
    (transportedGenericCubic_irreducible (k := k))

set_option maxHeartbeats 800000 in
theorem transportedGenericCubicToE_eq_cubic :
    transportedGenericCubicToE (k := k) =
      FieldExtension.cubic (k := k) := by
  simp only [transportedGenericCubicToE, transportedGenericCubic,
    Polynomial.mapEquiv_apply, GenericCubic.cubicOverF,
    GenericCubic.cubicOverA, Polynomial.map_add, Polynomial.map_mul,
    Polynomial.map_pow, Polynomial.map_C, Polynomial.map_X]
  simp only [RingHom.map_add, RingHom.map_mul, RingHom.map_pow]
  let hE : KQ (k := k) →+* FieldExtension.E (k := k) :=
    (KQ_to_E (k := k)).toRingHom
  let hG : GenericCubic.F (K := K (k := k)) →+* KQ (k := k) :=
    (genericToKQAlgEquiv (k := k)).toRingEquiv.toRingHom
  change
    Polynomial.X ^ 3 + Polynomial.X ^ 2 +
        (Polynomial.C
              (hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
                (GenericCubic.F (K := K (k := k))))
                (Polynomial.C (pInK (k := k)))))) *
            Polynomial.C
              (hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
                (GenericCubic.F (K := K (k := k))))
                (Polynomial.X : Polynomial (K (k := k)))))) +
          Polynomial.C
              (hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
                (GenericCubic.F (K := K (k := k))))
                (Polynomial.C (pInK (k := k)))))) ^ 3) *
          Polynomial.X +
      Polynomial.C
          (hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
            (GenericCubic.F (K := K (k := k))))
            (Polynomial.C (pInK (k := k)))))) ^ 3 =
      FieldExtension.cubic (k := k)
  have hC :
      hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
        (GenericCubic.F (K := K (k := k))))
        (Polynomial.C (pInK (k := k))))) =
        FieldExtension.targetInE (k := k) 0 := by
    dsimp [hE, hG]
    exact KQ_to_E_genericTo_A_C (k := k)
  have hX :
      hE (hG ((algebraMap (GenericCubic.A (K := K (k := k)))
        (GenericCubic.F (K := K (k := k))))
        (Polynomial.X : Polynomial (K (k := k))))) =
        FieldExtension.targetInE (k := k) 1 := by
    dsimp [hE, hG]
    exact KQ_to_E_genericTo_A_X (k := k)
  rw [hC, hX]
  simp only [FieldExtension.cubic,
    Polynomial.C_add, Polynomial.C_mul, Polynomial.C_pow]

theorem cubic_irreducible :
    Irreducible (FieldExtension.cubic (k := k)) := by
  rw [← transportedGenericCubicToE_eq_cubic (k := k)]
  exact transportedGenericCubicToE_irreducible (k := k)

/- The exact intermediate-field base requested by the transport. -/
theorem polynomial_adjoin_le_field_adjoin :
    A (k := k) ≤ (K (k := k)).toSubalgebra := by
  exact IntermediateField.algebra_adjoin_le_adjoin k
    ({Reconstruction.P (k := k)} : Set (L (k := k)))

/- This is the exact PUnit family needed by `aevalEquivField`. -/
abbrev RequiredKIndependent :=
  AlgebraicIndependent (ι := PUnit.{1}) (K (k := k))
    (fun _ : PUnit.{1} => Reconstruction.Q (k := k))

end

end DimensionTwoCounterexample.ActualIrreducibility
