import DimensionTwoCounterexample.CounterexampleStatement
import DimensionTwoCounterexample.FieldExtension

/-!
# Elementary part of the terminal counterexample

This file connects the uniform polynomial certificate to the exact base field
and affine morphism used by the terminal statement.  It also derives
coordinate-ring non-surjectivity directly from the explicit collision.

The declarations contain no placeholders.  They remain source-level evidence
until checked with the pinned Lean/Mathlib toolchain.
-/

namespace DimensionTwoCounterexample.Final

open MvPolynomial
open CategoryTheory

noncomputable section

theorem characteristic_two : CharP k 2 := inferInstance

theorem algebraically_closed : IsAlgClosed k := inferInstance

theorem origin_P : Generic.Pval (k := k) 0 0 = 0 := by
  exact congrArg Prod.fst (Generic.origin_value (k := k))

theorem origin_Q : Generic.Qval (k := k) 0 0 = 0 := by
  exact congrArg Prod.snd (Generic.origin_value (k := k))

theorem jacobian_at_origin : jacobianAt 0 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [jacobianAt, sourceCoordinate, sourceP, sourceQ, Generic.evalAt,
      Generic.pderiv_x_P, Generic.pderiv_y_P, Generic.pderiv_x_Q,
      Generic.pderiv_y_Q, Generic.x, Generic.y]

theorem jacobian_det :
    pderiv 0 sourceP * pderiv 1 sourceQ -
        pderiv 1 sourceP * pderiv 0 sourceQ = 1 := by
  simpa [sourceP, sourceQ] using Generic.jacobian_det (k := k)

theorem collision_01_10 : pointMap 0 1 = pointMap 1 0 := by
  funext i
  fin_cases i
  · exact congrArg Prod.fst (Generic.collision_01_10 (k := k))
  · exact congrArg Prod.snd (Generic.collision_01_10 (k := k))

theorem collision_01_11 : pointMap 0 1 = pointMap 1 1 := by
  funext i
  fin_cases i
  · exact congrArg Prod.fst (Generic.collision_01_11 (k := k))
  · exact congrArg Prod.snd (Generic.collision_01_11 (k := k))

theorem sourcePoint_01_ne_10 : sourcePoint 0 1 ≠ sourcePoint 1 0 := by
  intro h
  have h0 := congrFun h (0 : Fin 2)
  simpa [sourcePoint] using h0

theorem sourcePoint_01_ne_11 : sourcePoint 0 1 ≠ sourcePoint 1 1 := by
  intro h
  have h0 := congrFun h (0 : Fin 2)
  simpa [sourcePoint] using h0

theorem algebraicIndependent_target :
    AlgebraicIndependent k targetFamily := by
  simpa [targetFamily, pInFunctionField, qInFunctionField,
    sourceToFunctionField, sourceP, sourceQ, FieldExtension.target,
    Reconstruction.P, Reconstruction.Q, Reconstruction.includePolynomial] using
    (FieldExtension.algebraic_independent_target (k := k))

theorem coordinateRingHom_injective :
    Function.Injective coordinateRingHom := by
  intro f g hfg
  have hEval :
      Function.Injective
        (MvPolynomial.aeval targetFamily :
          TargetRing →ₐ[k] SourceFunctionField) :=
    algebraicIndependent_iff_injective_aeval.mp algebraicIndependent_target
  apply hEval
  have hmapped := congrArg
    (fun z => (IsScalarTower.toAlgHom k SourceRing SourceFunctionField) z) hfg
  change (IsScalarTower.toAlgHom k SourceRing SourceFunctionField)
      (MvPolynomial.aeval outputPolynomial f) =
    (IsScalarTower.toAlgHom k SourceRing SourceFunctionField)
      (MvPolynomial.aeval outputPolynomial g) at hmapped
  rw [MvPolynomial.comp_aeval_apply, MvPolynomial.comp_aeval_apply] at hmapped
  have hvec :
      (fun i => (IsScalarTower.toAlgHom k SourceRing SourceFunctionField)
        (outputPolynomial i)) = targetFamily := by
    funext i
    fin_cases i <;> rfl
  rw [hvec] at hmapped
  exact hmapped

private theorem eval_coordinateRingHom (f : TargetRing) (a b : k) :
    Generic.evalAt a b (coordinateRingHom f) =
      MvPolynomial.eval (pointMap a b) f := by
  change MvPolynomial.eval ![a, b]
      (MvPolynomial.bind₁ outputPolynomial f) =
    MvPolynomial.eval (pointMap a b) f
  change MvPolynomial.eval₂Hom (RingHom.id k) ![a, b]
      (MvPolynomial.bind₁ outputPolynomial f) = _
  rw [MvPolynomial.eval₂Hom_bind₁]
  change MvPolynomial.eval₂Hom (RingHom.id k)
      (fun i => MvPolynomial.eval₂Hom (RingHom.id k) ![a, b]
        (outputPolynomial i)) f =
    MvPolynomial.eval₂Hom (RingHom.id k) (pointMap a b) f
  have hv : (fun i => MvPolynomial.eval₂Hom (RingHom.id k) ![a, b]
      (outputPolynomial i)) = pointMap a b := by
    funext i
    fin_cases i
    · change Generic.evalAt a b sourceP = Generic.Pval a b
      simp [Generic.evalAt, sourceP, Generic.P, Generic.x, Generic.y,
        Generic.Pval]
    · change Generic.evalAt a b sourceQ = Generic.Qval a b
      simp [Generic.evalAt, sourceQ, Generic.Q, Generic.x, Generic.y,
        Generic.Qval]
  rw [hv]

theorem coordinateRingHom_not_surjective :
    ¬ Function.Surjective coordinateRingHom := by
  intro hsurj
  obtain ⟨f, hf⟩ := hsurj sourceX
  have hcollision :
      Generic.evalAt (0 : k) 1 (coordinateRingHom f) =
        Generic.evalAt 1 0 (coordinateRingHom f) := by
    rw [eval_coordinateRingHom, eval_coordinateRingHom, collision_01_10]
  rw [hf] at hcollision
  simpa [sourceX, Generic.evalAt, Generic.x] using hcollision

theorem affineMap_not_isIso : ¬ IsIso affineMap := by
  intro hIso
  have hSpec : IsIso
      (AlgebraicGeometry.Spec.map
        (CommRingCat.ofHom coordinateRingHom)) := by
    simpa [affineMap] using hIso
  have hbijective : Function.Bijective coordinateRingHom := by
    simpa [affineMap, coordinateRingHom] using
      (AlgebraicGeometry.isIso_SpecMap_iff.mp
        hSpec)
  exact coordinateRingHom_not_surjective hbijective.2

end

end DimensionTwoCounterexample.Final
