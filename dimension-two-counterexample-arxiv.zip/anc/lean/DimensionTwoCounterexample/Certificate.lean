import Mathlib

/-!
# Characteristic-two certificate for the dimension-two counterexample

This file deliberately certifies the computational/algebraic core before making
the much larger function-field argument:

* the expanded and compact forms of `P` and `Q`;
* the two partial derivatives and Jacobian determinant;
* the three-point collision over `𝔽₂`;
* the recovery identities;
* the cubic equation for the hidden element `w`;
* the derivative-at-`w` identity;
* the direct elimination cubic for `x`.

The exact field degree still requires a separate formal proof that the cubic is
irreducible over `k(P,Q)` and that `k(x,y) = k(P,Q,w)`.
-/

namespace DimensionTwoCounterexample

open MvPolynomial

abbrev F2 := ZMod 2
abbrev R2 := MvPolynomial (Fin 2) F2

noncomputable section

def x : R2 := X 0
def y : R2 := X 1

def P : R2 :=
  x + x ^ 2 * y + x ^ 4 + x ^ 6 * y ^ 2

def Q : R2 :=
  y + x ^ 5 + x ^ 6 * y + x ^ 7 * y ^ 2 + x ^ 8 * y ^ 3

def q : R2 := 1 + x * y
def u : R2 := 1 + x ^ 3 * q
def w : R2 := q * u ^ 2

def evalAt (a b : F2) : R2 →+* F2 :=
  eval ![a, b]

private lemma ofNat_eq_mod_two (n : ℕ) [n.AtLeastTwo] :
    (OfNat.ofNat n : R2) = (n % 2 : ℕ) := by
  rw [← Nat.cast_ofNat]
  exact CharP.cast_eq_mod R2 2 n

theorem P_compact : P = x * q * u := by
  simp only [P, q, u]
  ring_nf
  simp [CharTwo.two_eq_zero (R := R2)]

theorem Q_compact : Q = y + x ^ 5 * q ^ 3 := by
  simp only [Q, q]
  ring_nf
  simp [ofNat_eq_mod_two]

theorem x_ne_zero : x ≠ 0 := by
  intro hx
  have hx' := congrArg (evalAt 1 0) hx
  norm_num [evalAt, x] at hx'

theorem q_ne_zero : q ≠ 0 := by
  intro hq
  have hq' := congrArg (evalAt 0 0) hq
  norm_num [evalAt, q, x, y] at hq'

theorem u_ne_zero : u ≠ 0 := by
  intro hu
  have hu' := congrArg (evalAt 0 0) hu
  norm_num [evalAt, u, q, x, y] at hu'

theorem w_ne_zero : w ≠ 0 := by
  intro hw
  have hw' := congrArg (evalAt 0 0) hw
  norm_num [evalAt, w, u, q, x, y] at hw'

theorem P_ne_zero : P ≠ 0 := by
  rw [P_compact]
  exact mul_ne_zero (mul_ne_zero x_ne_zero q_ne_zero) u_ne_zero

theorem Q_ne_zero : Q ≠ 0 := by
  intro hQ
  have hQ' := congrArg (evalAt 0 1) hQ
  norm_num [evalAt, Q, x, y] at hQ'

theorem pderiv_x_P : pderiv 0 P = 1 := by
  simp [P, x, y, pderiv]
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

theorem pderiv_y_P : pderiv 1 P = x ^ 2 := by
  simp [P, x, y, pderiv]
  simp [CharTwo.two_eq_zero (R := R2)]

theorem pderiv_x_Q : pderiv 0 Q = x ^ 4 + x ^ 6 * y ^ 2 := by
  simp [Q, x, y, pderiv]
  simp [ofNat_eq_mod_two]
  ring_nf

theorem pderiv_y_Q : pderiv 1 Q = 1 + x ^ 6 + x ^ 8 * y ^ 2 := by
  simp [Q, x, y, pderiv]
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

theorem jacobian_det :
    pderiv 0 P * pderiv 1 Q - pderiv 1 P * pderiv 0 Q = 1 := by
  rw [pderiv_x_P, pderiv_y_P, pderiv_x_Q, pderiv_y_Q]
  ring_nf

def Pval (a b : F2) : F2 :=
  a + a ^ 2 * b + a ^ 4 + a ^ 6 * b ^ 2

def Qval (a b : F2) : F2 :=
  b + a ^ 5 + a ^ 6 * b + a ^ 7 * b ^ 2 + a ^ 8 * b ^ 3

theorem collision_01_10 :
    (Pval 0 1, Qval 0 1) = (Pval 1 0, Qval 1 0) := by
  change ((0 : F2), 1) = (2, 1)
  rw [CharTwo.two_eq_zero (R := F2)]

theorem collision_01_11 :
    (Pval 0 1, Qval 0 1) = (Pval 1 1, Qval 1 1) := by
  change ((0 : F2), 1) = (4, 5)
  have h2 : (2 : F2) = 0 := CharTwo.two_eq_zero
  have h4 : (4 : F2) = 0 := by
    calc
      (4 : F2) = 2 + 2 := by norm_num
      _ = 0 := by rw [h2]; simp
  have h5 : (5 : F2) = 1 := by
    calc
      (5 : F2) = 4 + 1 := by norm_num
      _ = 1 := by rw [h4]; simp
  rw [h4, h5]

theorem collision_value :
    (Pval 0 1, Qval 0 1) = (0, 1) := by
  norm_num [Pval, Qval]

theorem recovery_x : x * Q = 1 + w := by
  simp only [Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

theorem recovery_q : P ^ 2 = x ^ 2 * q * w := by
  rw [P_compact]
  simp only [w]
  ring_nf

theorem cubic_root :
    w ^ 3 + w ^ 2 + (P * Q + P ^ 3) * w + P ^ 3 = 0 := by
  simp only [P, Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

theorem cubic_derivative_at_w :
    w ^ 2 + P * Q + P ^ 3 = q * u := by
  simp only [P, Q, w, q, u]
  ring_nf
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

theorem elimination_cubic :
    Q ^ 2 * x ^ 3 + (P ^ 3 + P * Q + 1) * x + P = 0 := by
  simp only [P, Q]
  ring_nf
  simp [ofNat_eq_mod_two, CharTwo.two_eq_zero (R := R2)]

end

end DimensionTwoCounterexample
