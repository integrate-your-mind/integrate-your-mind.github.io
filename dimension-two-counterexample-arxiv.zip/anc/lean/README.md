# Dimension-two characteristic-two counterexample: complete Lean source bundle

This project targets the exact end-to-end theorem
`DimensionTwoCounterexample.Final.fullCounterexample` over
`k = AlgebraicClosure (ZMod 2)`.  The root module imports that theorem.

The current source contains:

- the uniform characteristic-two polynomial certificate and all nonzero
  denominator obligations;
- fraction-field reconstruction and `k(P,Q)` algebraic independence;
- exact cubic irreducibility over the actual target function field;
- `minpoly`, `finrank = 3`, separability, and finite separable degree;
- a graph-presentation proof of scheme-level étaleness;
- the geometric generic-fiber equivalence with function-field embeddings and
  cardinality three;
- the collision-based coordinate-ring and affine-scheme noninvertibility
  conclusions;
- the exact terminal conjunction and the separate three-variable structural
  identities from the supplied proof.

The exact terminal theorem and root library were **kernel-checked** at pushed
source commit `ab26ce21e3b272eec73908d5ed2f8b10117f2e38` with the pinned Lean
4.28.0/Mathlib v4.28.0 toolchain on Apple arm64. The terminal axiom audit
reports only Lean's standard `propext`, `Classical.choice`, and `Quot.sound`;
the source audit finds no `sorry`, `admit`, custom `axiom`, or `unsafe`
declaration. The verification used the historical `.lake` cache; it was safely
removed afterward, so no fresh local cache-free replay is claimed.

A separate digest-locked Harmonic Aristotle audit has now independently
reproduced the exact `GeometricBridge`, `FinalTheorem`, root-library, and
`KernelAudit.lean` commands with the same Lean/Mathlib revisions and axiom
output. It also accepted the exact terminal statement without a weakened or
substitute theorem. This is external corroboration, not a substitute for the
local kernel receipt.

See `CLOSURE_LEDGER.md` for theorem-by-theorem status and
`KERNEL_RECEIPT.md` for the reproducible terminal receipt.
`ARISTOTLE_RECEIPT.md` records the independent terminal replay and its
environment-normalization caveat.
`SOURCE_DIGESTS.sha256` provides a machine-checkable identity for every Lean
source and pinned toolchain file.
`FORMALIZATION_MAP.md` maps each informal proof section to its exact Lean
declarations and explains the separate geometric generic-fiber bridge.
`PRESERVATION_MANIFEST.md` records recovery paths and hashes.

The accompanying prose source is `source-solution.txt`.
