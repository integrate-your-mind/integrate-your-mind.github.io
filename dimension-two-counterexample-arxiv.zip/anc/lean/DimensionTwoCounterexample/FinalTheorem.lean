import DimensionTwoCounterexample.ActualIrreducibility
import DimensionTwoCounterexample.EtalePresentation
import DimensionTwoCounterexample.FinalElementary
import DimensionTwoCounterexample.GeometricBridge

/-!
# The complete dimension-two characteristic-two counterexample

This module assembles the exact terminal proposition from the independently
factored computational, field-theoretic, étale, geometric, and
noninvertibility proofs.

The exact kernel commands, source/object digests, source audit, and axiom audit
for this declaration are recorded in `KERNEL_RECEIPT.md`.
-/

namespace DimensionTwoCounterexample.Final

noncomputable section

theorem fullCounterexample : FullCounterexampleStatement := by
  have hirr : Irreducible (FieldExtension.cubic (k := k)) :=
    ActualIrreducibility.cubic_irreducible (k := k)
  refine ⟨
    characteristic_two,
    algebraically_closed,
    origin_P,
    origin_Q,
    jacobian_at_origin,
    jacobian_det,
    collision_01_10,
    collision_01_11,
    sourcePoint_01_ne_10,
    sourcePoint_01_ne_11,
    EtalePresentation.affineMap_etale,
    algebraicIndependent_target,
    coordinateRingHom_injective,
    DegreeFromIrreducible.finrank_eq_three (k := k) hirr,
    DegreeFromIrreducible.extension_isSeparable (k := k) hirr,
    DegreeFromIrreducible.finSepDegree_eq_three (k := k) hirr,
    ⟨GeometricBridge.geometricFiberPointFunctionFieldEmbeddingEquiv hirr⟩,
    GeometricBridge.geometricFiberPoint_natCard_eq_three hirr,
    DegreeFromIrreducible.finrank_coprime_two (k := k) hirr,
    coordinateRingHom_not_surjective,
    affineMap_not_isIso⟩

end

end DimensionTwoCounterexample.Final
