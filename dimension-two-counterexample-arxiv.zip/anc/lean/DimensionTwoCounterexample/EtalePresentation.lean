import DimensionTwoCounterexample.CounterexampleStatement

/-!
# A graph presentation for the étale calculation

The source and target coordinate rings in the counterexample are definitionally
the same Lean type.  Their algebra structure is not the identity algebra
structure, however: it is induced by the explicit coordinate map.  To keep
typeclass inference from replacing that structure by `Algebra.id`, the graph
presentation below lands first in the ring-equivalent type
`SourceCopy`.  At the end we transport the presentation across the
explicit algebra equivalence back to the literal source coordinate ring.

The graph relations are `P(X,Y)-A` and `Q(X,Y)-B`; their Jacobian is therefore
the already certified Jacobian of `(P,Q)`.
-/

namespace DimensionTwoCounterexample.Final.EtalePresentation

open MvPolynomial

noncomputable section

abbrev sourceAlgebra : Algebra TargetRing SourceRing :=
  coordinateAlgHom.toRingHom.toAlgebra

structure SourceCopy where
  down : SourceRing

namespace SourceCopy

def up (x : SourceRing) : SourceCopy := ⟨x⟩

@[ext]
theorem ext {x y : SourceCopy} (h : x.down = y.down) : x = y := by
  cases x
  cases y
  cases h
  rfl

instance : Zero SourceCopy := ⟨up 0⟩
instance : One SourceCopy := ⟨up 1⟩
instance : Add SourceCopy := ⟨fun x y => up (x.down + y.down)⟩
instance : Mul SourceCopy := ⟨fun x y => up (x.down * y.down)⟩
instance : Neg SourceCopy := ⟨fun x => up (-x.down)⟩
instance : Sub SourceCopy := ⟨fun x y => up (x.down - y.down)⟩
instance : SMul ℕ SourceCopy := ⟨fun n x => up (n • x.down)⟩
instance : SMul ℤ SourceCopy := ⟨fun n x => up (n • x.down)⟩
instance : Pow SourceCopy ℕ := ⟨fun x n => up (x.down ^ n)⟩
instance : NatCast SourceCopy := ⟨fun n => up n⟩
instance : IntCast SourceCopy := ⟨fun n => up n⟩

instance : CommRing SourceCopy :=
  Function.Injective.commRing down (by
    intro x y h
    exact ext h)
    rfl rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ => rfl)
    (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
    (fun _ _ => rfl) (fun _ => rfl) (fun _ => rfl)

@[simp] theorem up_add (x y : SourceRing) : up x + up y = up (x + y) := rfl
@[simp] theorem up_mul (x y : SourceRing) : up x * up y = up (x * y) := rfl
@[simp] theorem down_up (x : SourceRing) : (up x).down = x := rfl

def ringEquiv : SourceCopy ≃+* SourceRing where
  toFun := down
  invFun := up
  left_inv := by intro x; exact ext rfl
  right_inv := by intro x; rfl
  map_add' := by intros; rfl
  map_mul' := by intros; rfl

end SourceCopy

abbrev sourceCopyAlgebra : Algebra TargetRing SourceCopy :=
  (SourceCopy.ringEquiv.symm.toRingHom.comp coordinateRingHom).toAlgebra

local instance sourceCopyAlgebraInstance : Algebra TargetRing SourceCopy :=
  sourceCopyAlgebra

@[simp]
theorem sourceCopy_algebraMap_apply (f : TargetRing) :
    algebraMap TargetRing SourceCopy f =
      SourceCopy.up (coordinateRingHom f) := by
  apply SourceCopy.ext
  rfl

abbrev GraphPolynomialRing := MvPolynomial (Fin 2) TargetRing

def sourceVariable : Fin 2 → SourceRing :=
  ![sourceX, sourceY]

def sourceCopyVariable : Fin 2 → SourceCopy :=
  fun i => SourceCopy.up (sourceVariable i)

@[simp]
theorem sourceVariable_eq_X (i : Fin 2) : sourceVariable i = X i := by
  fin_cases i <;> rfl

@[simp]
theorem sourceCopyVariable_eq_up_X (i : Fin 2) :
    sourceCopyVariable i = SourceCopy.up (X i) := by
  rw [sourceCopyVariable, sourceVariable_eq_X]

def liftSourcePolynomial (f : SourceRing) : GraphPolynomialRing :=
  MvPolynomial.map (algebraMap k TargetRing) f

def graphRelation (i : Fin 2) : GraphPolynomialRing :=
  liftSourcePolynomial (outputPolynomial i) - C (X i)

def graphIdeal : Ideal GraphPolynomialRing :=
  Ideal.span (Set.range graphRelation)

abbrev GraphQuotient := GraphPolynomialRing ⧸ graphIdeal

noncomputable def graphPrePresentation :
    Algebra.PreSubmersivePresentation TargetRing GraphQuotient (Fin 2) (Fin 2) :=
  Algebra.PreSubmersivePresentation.naive
    (v := graphRelation) id Function.injective_id

def graphEvaluation :
    @AlgHom TargetRing GraphPolynomialRing SourceCopy _ _ _ inferInstance
      sourceCopyAlgebra := by
  exact @MvPolynomial.aeval TargetRing SourceCopy (Fin 2) _ _
    sourceCopyAlgebra sourceCopyVariable

@[simp]
theorem graphEvaluation_liftSourcePolynomial (f : SourceRing) :
    graphEvaluation (liftSourcePolynomial f) = SourceCopy.up f := by
  induction f using MvPolynomial.induction_on with
  | C a =>
      simp [graphEvaluation, liftSourcePolynomial, SourceCopy.up,
        coordinateRingHom, coordinateAlgHom]
  | add f g hf hg =>
      rw [liftSourcePolynomial, map_add, map_add]
      change
        graphEvaluation (liftSourcePolynomial f) +
            graphEvaluation (liftSourcePolynomial g) =
          SourceCopy.up (f + g)
      rw [hf, hg]
      rfl
  | mul_X f i hf =>
      rw [liftSourcePolynomial, map_mul, map_X, map_mul]
      have hX : graphEvaluation (X i) = sourceCopyVariable i := by
        simp [graphEvaluation]
      rw [hX]
      change
        graphEvaluation (liftSourcePolynomial f) * sourceCopyVariable i =
          SourceCopy.up (f * X i)
      rw [hf, sourceCopyVariable_eq_up_X]
      rfl

@[simp]
theorem graphEvaluation_graphRelation (i : Fin 2) :
    graphEvaluation (graphRelation i) = 0 := by
  rw [graphRelation, map_sub, graphEvaluation_liftSourcePolynomial]
  fin_cases i <;>
    simp [graphEvaluation, sourceCopyVariable, sourceVariable,
      coordinateRingHom, coordinateAlgHom, outputPolynomial, SourceCopy.up]

theorem graphIdeal_le_kernel :
    graphIdeal ≤ RingHom.ker graphEvaluation.toRingHom := by
  rw [graphIdeal, Ideal.span_le]
  rintro f ⟨i, rfl⟩
  exact RingHom.mem_ker.mpr (graphEvaluation_graphRelation i)

noncomputable def graphQuotientToSourceCopy :
    @AlgHom TargetRing GraphQuotient SourceCopy _ _ _ inferInstance
      sourceCopyAlgebra := by
  exact Ideal.Quotient.liftₐ graphIdeal graphEvaluation
    (fun f hf => RingHom.mem_ker.mp (graphIdeal_le_kernel hf))

def graphVariable (i : Fin 2) : GraphQuotient :=
  Ideal.Quotient.mk graphIdeal (X i)

def sourceToGraphQuotient : SourceRing →+* GraphQuotient :=
  (Ideal.Quotient.mk graphIdeal).comp
    (MvPolynomial.map (algebraMap k TargetRing))

@[simp]
theorem graphQuotientToSourceCopy_graphVariable (i : Fin 2) :
    graphQuotientToSourceCopy (graphVariable i) = sourceCopyVariable i := by
  fin_cases i <;>
    simp [graphQuotientToSourceCopy, graphVariable, graphEvaluation,
      sourceCopyVariable]

@[simp]
theorem sourceToGraphQuotient_liftSourcePolynomial (f : SourceRing) :
    sourceToGraphQuotient f =
      Ideal.Quotient.mk graphIdeal (liftSourcePolynomial f) := by
  rfl

theorem graphRelation_eq_zero (i : Fin 2) :
    Ideal.Quotient.mk graphIdeal (graphRelation i) = 0 := by
  rw [Ideal.Quotient.eq_zero_iff_mem]
  exact Ideal.subset_span (Set.mem_range_self i)

@[simp]
theorem sourceToGraphQuotient_outputPolynomial (i : Fin 2) :
    sourceToGraphQuotient (outputPolynomial i) =
      algebraMap TargetRing GraphQuotient (X i) := by
  have h := graphRelation_eq_zero i
  rw [graphRelation, map_sub] at h
  have h' :
      Ideal.Quotient.mk graphIdeal
          (liftSourcePolynomial (outputPolynomial i)) =
        Ideal.Quotient.mk graphIdeal (C (X i)) :=
    sub_eq_zero.mp h
  rw [sourceToGraphQuotient_liftSourcePolynomial]
  exact h'

noncomputable def sourceCopyToGraphQuotient :
    @AlgHom TargetRing SourceCopy GraphQuotient _ _ _ sourceCopyAlgebra
      inferInstance where
  __ := sourceToGraphQuotient.comp SourceCopy.ringEquiv.toRingHom
  commutes' := by
    intro f
    have h :
        sourceToGraphQuotient.comp coordinateRingHom =
          algebraMap TargetRing GraphQuotient := by
      apply MvPolynomial.ringHom_ext
      · intro a
        simp [sourceToGraphQuotient, coordinateRingHom, coordinateAlgHom,
          Ideal.Quotient.alg_map_eq, MvPolynomial.algebraMap_eq]
      · intro i
        simpa [coordinateRingHom, coordinateAlgHom] using
          sourceToGraphQuotient_outputPolynomial i
    exact DFunLike.congr_fun h f

theorem graphQuotientToSourceCopy_rightInverse :
    Function.RightInverse
      sourceCopyToGraphQuotient graphQuotientToSourceCopy := by
  intro f
  change
    graphQuotientToSourceCopy (sourceCopyToGraphQuotient f) = f
  apply SourceCopy.ringEquiv.injective
  change
    (graphQuotientToSourceCopy
      (sourceToGraphQuotient f.down)).down = f.down
  have h :
      ((SourceCopy.ringEquiv.toRingHom.comp
          graphQuotientToSourceCopy.toRingHom).comp
          sourceToGraphQuotient) =
        RingHom.id SourceRing := by
    apply MvPolynomial.ringHom_ext
    · intro a
      change
        SourceCopy.ringEquiv
            (graphEvaluation (liftSourcePolynomial (C a))) =
          C a
      rw [graphEvaluation_liftSourcePolynomial]
      rfl
    · intro i
      fin_cases i <;>
        simp [graphQuotientToSourceCopy, graphEvaluation, graphVariable,
          sourceToGraphQuotient, sourceCopyAlgebra, SourceCopy.ringEquiv,
          SourceCopy.up, sourceCopyVariable, sourceVariable, sourceX, sourceY,
          Generic.x, Generic.y, liftSourcePolynomial]
  exact DFunLike.congr_fun h f.down

theorem graphQuotientToSourceCopy_leftInverse :
    Function.LeftInverse
      sourceCopyToGraphQuotient graphQuotientToSourceCopy := by
  intro f
  change
    sourceCopyToGraphQuotient (graphQuotientToSourceCopy f) = f
  have h :
      sourceCopyToGraphQuotient.comp graphQuotientToSourceCopy =
        AlgHom.id TargetRing GraphQuotient := by
    apply Ideal.Quotient.algHom_ext
    apply MvPolynomial.algHom_ext
    intro i
    fin_cases i <;>
      simp [sourceCopyToGraphQuotient, sourceToGraphQuotient,
        graphQuotientToSourceCopy, graphEvaluation, graphVariable,
        sourceCopyAlgebra, SourceCopy.ringEquiv, SourceCopy.up,
        sourceCopyVariable, sourceVariable, sourceX, sourceY,
        Generic.x, Generic.y, liftSourcePolynomial]
  exact DFunLike.congr_fun h f

theorem graphQuotientToSourceCopy_bijective :
    Function.Bijective graphQuotientToSourceCopy :=
  ⟨graphQuotientToSourceCopy_leftInverse.injective,
    graphQuotientToSourceCopy_rightInverse.surjective⟩

noncomputable def graphQuotientEquivSourceCopy :
    @AlgEquiv TargetRing GraphQuotient SourceCopy _ _ _ inferInstance
      sourceCopyAlgebra := by
  exact AlgEquiv.ofBijective graphQuotientToSourceCopy
    graphQuotientToSourceCopy_bijective

noncomputable def sourceCopyEquivSource :
    @AlgEquiv TargetRing SourceCopy SourceRing _ _ _ sourceCopyAlgebra
      sourceAlgebra := by
  letI : Algebra TargetRing SourceRing := sourceAlgebra
  exact
    { SourceCopy.ringEquiv with
      commutes' := by
        intro f
        rfl }

theorem graphPrePresentation_jacobian_eq_one :
    graphPrePresentation.jacobian = 1 := by
  rw [Algebra.PreSubmersivePresentation.jacobian_eq_jacobiMatrix_det,
    Matrix.det_fin_two]
  simp only [graphPrePresentation,
    Algebra.PreSubmersivePresentation.jacobiMatrix_apply]
  have h := congrArg
    (fun f : SourceRing =>
      algebraMap GraphPolynomialRing GraphQuotient
        (liftSourcePolynomial f))
    (Generic.jacobian_det (k := k))
  simpa [graphRelation, liftSourcePolynomial, outputPolynomial,
    MvPolynomial.pderiv_map, mul_comm] using h

noncomputable def graphSubmersivePresentation :
    Algebra.SubmersivePresentation
      TargetRing GraphQuotient (Fin 2) (Fin 2) where
  __ := graphPrePresentation
  jacobian_isUnit := by
    rw [graphPrePresentation_jacobian_eq_one]
    exact isUnit_one

noncomputable def sourceSubmersivePresentation :
    @Algebra.SubmersivePresentation TargetRing SourceRing (Fin 2) (Fin 2)
      _ _ sourceAlgebra inferInstance := by
  let e :
      @AlgEquiv TargetRing GraphQuotient SourceRing _ _ _ inferInstance
        sourceAlgebra :=
    @AlgEquiv.trans TargetRing GraphQuotient SourceCopy SourceRing _ _ _ _
      inferInstance sourceCopyAlgebra sourceAlgebra
      graphQuotientEquivSourceCopy sourceCopyEquivSource
  exact
    @Algebra.SubmersivePresentation.ofAlgEquiv
      TargetRing GraphQuotient (Fin 2) (Fin 2) _ _ inferInstance
      inferInstance graphSubmersivePresentation SourceRing _ sourceAlgebra e

theorem targetRing_etale_sourceRing :
    @Algebra.Etale TargetRing SourceRing _ _ sourceAlgebra := by
  let P₀ :
      @Algebra.SubmersivePresentation TargetRing SourceRing (Fin 2) (Fin 2)
        _ _ sourceAlgebra inferInstance :=
    sourceSubmersivePresentation
  letI : Algebra TargetRing SourceRing := sourceAlgebra
  let P : Algebra.SubmersivePresentation
      TargetRing SourceRing (Fin 2) (Fin 2) :=
    P₀
  have hdim : P.toPreSubmersivePresentation.dimension = 0 := by
    simp [Algebra.Presentation.dimension]
  have hstd :
      Algebra.IsStandardSmoothOfRelativeDimension 0 TargetRing SourceRing :=
    P.isStandardSmoothOfRelativeDimension hdim
  letI :
      Algebra.IsStandardSmoothOfRelativeDimension 0 TargetRing SourceRing :=
    hstd
  infer_instance

theorem coordinateRingHom_etale :
    coordinateRingHom.Etale := by
  change @Algebra.Etale TargetRing SourceRing _ _ coordinateRingHom.toAlgebra
  exact targetRing_etale_sourceRing

theorem affineMap_etale :
    AlgebraicGeometry.Etale affineMap := by
  simpa [affineMap] using
    (AlgebraicGeometry.HasRingHomProperty.Spec_iff
      (P := @AlgebraicGeometry.Etale)
      (φ := CommRingCat.ofHom coordinateRingHom)).mpr coordinateRingHom_etale

end

end DimensionTwoCounterexample.Final.EtalePresentation
