import DimensionTwoCounterexample.FieldExtension

/-!
# Degree and separability consequences of cubic irreducibility

This file deliberately takes irreducibility of the displayed cubic as its
only new hypothesis.  It does not assert the Gauss-lemma step which would
produce that hypothesis.
-/

namespace DimensionTwoCounterexample.DegreeFromIrreducible

open MvPolynomial
open Polynomial

noncomputable section

variable {k : Type*} [Field k] [CharP k 2]

set_option synthInstance.maxHeartbeats 100000

abbrev R := FieldExtension.R (k := k)
abbrev L := FieldExtension.L (k := k)
abbrev E := FieldExtension.E (k := k)

local notation "w" => Reconstruction.w (k := k)

private theorem cubic_as_standard_cubic :
    FieldExtension.cubic (k := k) =
      Polynomial.C (1 : E (k := k)) * Polynomial.X ^ 3 +
        Polynomial.C (1 : E (k := k)) * Polynomial.X ^ 2 +
          Polynomial.C
              (FieldExtension.targetInE (k := k) 0 *
                FieldExtension.targetInE (k := k) 1 +
                FieldExtension.targetInE (k := k) 0 ^ 3) *
            Polynomial.X +
          Polynomial.C (FieldExtension.targetInE (k := k) 0 ^ 3) := by
  unfold FieldExtension.cubic
  rw [Polynomial.C_1]
  simp only [one_mul]

private theorem cubic_natDegree :
    (FieldExtension.cubic (k := k)).natDegree = 3 := by
  rw [cubic_as_standard_cubic (k := k)]
  exact Polynomial.natDegree_cubic
    (one_ne_zero : (1 : E (k := k)) ≠ 0)

theorem minpoly_eq_cubic
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    minpoly (E (k := k)) w = FieldExtension.cubic (k := k) := by
  exact (minpoly.eq_of_irreducible_of_monic hirr
    (FieldExtension.cubic_root (k := k))
    (FieldExtension.cubic_monic (k := k))).symm

theorem finrank_eq_three
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Module.finrank (E (k := k)) (L (k := k)) = 3 := by
  let K := IntermediateField.adjoin (E (k := k)) {w}
  have hw : IsIntegral (E (k := k)) w := by
    exact ⟨FieldExtension.cubic (k := k),
      FieldExtension.cubic_monic (k := k),
      FieldExtension.cubic_root (k := k)⟩
  have hdim := IntermediateField.adjoin.finrank hw
  rw [FieldExtension.adjoin_hidden_eq_top (k := k)] at hdim
  rw [minpoly_eq_cubic (k := k) hirr] at hdim
  simpa only [cubic_natDegree (k := k),
    IntermediateField.finrank_top'] using hdim

theorem cubic_derivative_at_hidden :
    Polynomial.aeval w
        (Polynomial.derivative (FieldExtension.cubic (k := k))) =
      Reconstruction.q (k := k) * Reconstruction.u (k := k) := by
  rw [cubic_as_standard_cubic (k := k)]
  simp only [Polynomial.derivative_add, Polynomial.derivative_mul,
    Polynomial.derivative_C, Polynomial.derivative_X,
    Polynomial.derivative_pow, zero_mul, mul_zero, zero_add, one_mul,
    Polynomial.aeval_add, Polynomial.aeval_mul, Polynomial.aeval_C,
    Polynomial.aeval_X, Polynomial.aeval_one, Polynomial.aeval_zero,
    map_pow, map_one, map_zero, pow_zero, pow_one, Nat.reduceSub,
    mul_one, add_zero, map_ofNat]
  change
    (3 : E (k := k)) * w ^ 2 + (2 : E (k := k)) * w +
        (FieldExtension.targetInE (k := k) 0 *
          FieldExtension.targetInE (k := k) 1 +
          FieldExtension.targetInE (k := k) 0 ^ 3) =
      Reconstruction.q (k := k) * Reconstruction.u (k := k)
  rw [CharTwo.two_eq_zero (R := E (k := k))]
  norm_num
  have hthreeE : (3 : E (k := k)) = 1 := by
    calc
      (3 : E (k := k)) = 2 + 1 := by norm_num
      _ = 0 + 1 := by rw [CharTwo.two_eq_zero (R := E (k := k))]
      _ = 1 := zero_add 1
  have hthree : ((3 : E (k := k)) : L (k := k)) = 1 := by
    rw [hthreeE]
    exact map_one (algebraMap (E (k := k)) (L (k := k)))
  rw [hthree]
  rw [one_mul]
  rw [FieldExtension.targetInE_apply_zero (k := k),
    FieldExtension.targetInE_apply_one (k := k)]
  simpa only [add_assoc] using
    Reconstruction.cubic_derivative_at_w_mapped (k := k)

theorem cubic_derivative_at_hidden_ne_zero :
    Polynomial.aeval w
        (Polynomial.derivative (FieldExtension.cubic (k := k))) ≠ 0 := by
  rw [cubic_derivative_at_hidden (k := k)]
  exact mul_ne_zero
    (Reconstruction.q_ne_zero (k := k))
    (Reconstruction.u_ne_zero (k := k))

theorem cubic_derivative_ne_zero
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Polynomial.derivative (FieldExtension.cubic (k := k)) ≠ 0 := by
  intro hzero
  have hcoeff := congrArg (fun p : Polynomial (E (k := k)) => p.coeff 2) hzero
  change
    (Polynomial.derivative (FieldExtension.cubic (k := k))).coeff 2 = 0
      at hcoeff
  rw [Polynomial.coeff_derivative] at hcoeff
  have htop :
      (FieldExtension.cubic (k := k)).coeff 3 = 1 := by
    rw [← cubic_natDegree (k := k)]
    exact (FieldExtension.cubic_monic (k := k)).coeff_natDegree
  rw [htop] at hcoeff
  rw [CharP.cast_eq_mod (E (k := k)) 2 2] at hcoeff
  norm_num at hcoeff

theorem cubic_separable
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    (FieldExtension.cubic (k := k)).Separable :=
  (Polynomial.separable_iff_derivative_ne_zero hirr).2
    (cubic_derivative_ne_zero (k := k) hirr)

theorem hidden_isSeparable
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    IsSeparable (E (k := k)) w := by
  simpa [IsSeparable, minpoly_eq_cubic (k := k) hirr] using
    cubic_separable (k := k) hirr

theorem extension_isSeparable
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Algebra.IsSeparable (E (k := k)) (L (k := k)) := by
  have hs : Algebra.IsSeparable (E (k := k))
      (IntermediateField.adjoin (E (k := k)) {w}) :=
    (IntermediateField.isSeparable_adjoin_simple_iff_isSeparable
      (E (k := k)) (L (k := k))).2
      (hidden_isSeparable (k := k) hirr)
  rw [FieldExtension.adjoin_hidden_eq_top (k := k)] at hs
  letI : Algebra.IsSeparable (E (k := k))
      (⊤ : IntermediateField (E (k := k)) (L (k := k))) := hs
  exact AlgEquiv.Algebra.isSeparable
    (IntermediateField.topEquiv :
      (⊤ : IntermediateField (E (k := k)) (L (k := k))) ≃ₐ[E (k := k)]
        L (k := k))

theorem finSepDegree_eq_three
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Field.finSepDegree (E (k := k)) (L (k := k)) = 3 := by
  letI : Algebra.IsSeparable (E (k := k)) (L (k := k)) :=
    extension_isSeparable (k := k) hirr
  calc
    Field.finSepDegree (E (k := k)) (L (k := k)) =
        Module.finrank (E (k := k)) (L (k := k)) :=
      Field.finSepDegree_eq_finrank_of_isSeparable
        (E (k := k)) (L (k := k))
    _ = 3 := finrank_eq_three (k := k) hirr

theorem finrank_coprime_two
    (hirr : Irreducible (FieldExtension.cubic (k := k))) :
    Nat.Coprime (Module.finrank (E (k := k)) (L (k := k))) 2 := by
  rw [finrank_eq_three (k := k) hirr]
  norm_num

end

end DimensionTwoCounterexample.DegreeFromIrreducible
