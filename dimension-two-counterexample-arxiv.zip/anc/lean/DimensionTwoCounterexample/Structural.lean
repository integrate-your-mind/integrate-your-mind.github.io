import DimensionTwoCounterexample.Certificate

/-!
# Certificate for the three-variable to two-variable reduction

This file checks the novel structural step in the supplied solution.  The
three-variable source-coordinate change is inverted explicitly, the preserved
coordinate is identified, and restriction to its zero fiber is expanded to
the two-variable pair `P,Q`.
-/

namespace DimensionTwoCounterexample

open MvPolynomial

abbrev R3 := MvPolynomial (Fin 3) F2

noncomputable section

namespace Structural

def sx : R3 := X 0
def sy : R3 := X 1
def sz : R3 := X 2

def a : R3 := sx
def b : R3 := sz + sy ^ 2
def c : R3 := sx + sy + sx ^ 2 * b

def inverseX : R3 := a
def inverseY : R3 := c + a + a ^ 2 * b
def inverseZ : R3 := b + inverseY ^ 2

theorem source_change_recovers_x : inverseX = sx := by
  rfl

theorem source_change_recovers_y : inverseY = sy := by
  simp only [inverseY, c, a, b]
  ring_nf
  simp [CharTwo.two_eq_zero (R := R3)]

theorem source_change_recovers_z : inverseZ = sz := by
  rw [inverseZ, source_change_recovers_y]
  simp only [b]
  ring_nf
  simp [CharTwo.two_eq_zero (R := R3)]

/- The two directions of the source-coordinate change are recorded
   explicitly.  The first direction is the displayed inverse map evaluated
   on the original coordinates; the second reconstructs the coordinates
   `(a,b,c)` from the inverse expressions. -/

theorem source_change_forward_a : a = sx := by
  rfl

theorem source_change_forward_b : b = sz + sy ^ 2 := by
  rfl

theorem source_change_forward_c :
    c = sx + sy + sx ^ 2 * (sz + sy ^ 2) := by
  simp [c, b]

theorem source_change_inverse_a : inverseX = a := by
  rfl

theorem source_change_inverse_b : inverseZ + inverseY ^ 2 = b := by
  rw [source_change_recovers_z, source_change_recovers_y]
  simp [b]

theorem source_change_inverse_c :
    inverseX + inverseY + inverseX ^ 2 * (inverseZ + inverseY ^ 2) = c := by
  rw [source_change_recovers_x, source_change_recovers_y,
    source_change_recovers_z]
  simp [c, b]

theorem source_change_inverse_direction :
    inverseX = sx ∧ inverseY = sy ∧ inverseZ = sz := by
  exact ⟨source_change_recovers_x, source_change_recovers_y,
    source_change_recovers_z⟩

theorem source_change_forward_direction :
    a = sx ∧ b = sz + sy ^ 2 ∧
      c = sx + sy + sx ^ 2 * (sz + sy ^ 2) := by
  exact ⟨source_change_forward_a, source_change_forward_b,
    source_change_forward_c⟩

theorem source_change_inverse_on_coordinates :
    inverseX = a ∧ inverseZ + inverseY ^ 2 = b ∧
      inverseX + inverseY + inverseX ^ 2 * (inverseZ + inverseY ^ 2) = c := by
  exact ⟨source_change_inverse_a, source_change_inverse_b,
    source_change_inverse_c⟩

def PhiX : R3 := sx + sx ^ 2 * sz
def PhiY : R3 := sy + sx ^ 2 * sy ^ 2
def PhiZ : R3 := sz + sx * sy + sx ^ 2 * sy * sz

/- The published map is

     G(x,y,z) = (x+x^2*y, y+x*z+x^2*y*z, z+x^2*z^2).

 Swapping the source variables `y,z` gives the three expressions below.
 Swapping the second and third target coordinates then produces `Phi`.
 These are component identities only; no scheme-level conjugacy is claimed
 here. -/

def G1At (X Y Z : R3) : R3 := X + X ^ 2 * Y
def G2At (X Y Z : R3) : R3 := Y + X * Z + X ^ 2 * Y * Z
def G3At (X Y Z : R3) : R3 := Z + X ^ 2 * Z ^ 2

def G1 : R3 := G1At sx sy sz
def G2 : R3 := G2At sx sy sz
def G3 : R3 := G3At sx sy sz

def sourceSwapG1 : R3 := G1At sx sz sy
def sourceSwapG2 : R3 := G2At sx sz sy
def sourceSwapG3 : R3 := G3At sx sz sy

def conjugatedG1 : R3 := sourceSwapG1
def conjugatedG2 : R3 := sourceSwapG3
def conjugatedG3 : R3 := sourceSwapG2

theorem source_swap_G1_eq_PhiX : sourceSwapG1 = PhiX := by
  rfl

theorem source_swap_G2_eq_PhiZ : sourceSwapG2 = PhiZ := by
  simp only [sourceSwapG2, G2At, PhiZ]
  ring

theorem source_swap_G3_eq_PhiY : sourceSwapG3 = PhiY := by
  rfl

theorem target_swap_source_swap_G :
    conjugatedG1 = PhiX ∧ conjugatedG2 = PhiY ∧ conjugatedG3 = PhiZ := by
  constructor
  · exact source_swap_G1_eq_PhiX
  constructor
  · exact source_swap_G3_eq_PhiY
  · exact source_swap_G2_eq_PhiZ

theorem source_swap_G_components :
    sourceSwapG1 = PhiX ∧ sourceSwapG2 = PhiZ ∧ sourceSwapG3 = PhiY := by
  exact ⟨source_swap_G1_eq_PhiX, source_swap_G2_eq_PhiZ,
    source_swap_G3_eq_PhiY⟩

theorem preserved_coordinate : PhiX + PhiY = c := by
  simp only [PhiX, PhiY, c, b]
  ring_nf

private lemma ofNat_eq_mod_two_R2 (n : ℕ) [n.AtLeastTwo] :
    (OfNat.ofNat n : R2) = (n % 2 : ℕ) := by
  rw [← Nat.cast_ofNat]
  exact CharP.cast_eq_mod R2 2 n

def fiberSourceY : R2 := x + x ^ 2 * y
def fiberSourceZ : R2 := y + fiberSourceY ^ 2

theorem fiber_lies_in_c_zero :
    x + fiberSourceY + x ^ 2 * y = 0 := by
  simp only [fiberSourceY]
  ring_nf
  simp [CharTwo.two_eq_zero (R := R2)]

def fiberA : R2 := x + x ^ 2 * fiberSourceZ
def fiberB : R2 :=
  fiberSourceZ + x * fiberSourceY + x ^ 2 * fiberSourceY * fiberSourceZ

theorem fiber_first_coordinate : fiberA = P := by
  simp only [fiberA, fiberSourceZ, fiberSourceY, P]
  ring_nf
  simp [CharTwo.two_eq_zero (R := R2)]

theorem fiber_second_coordinate : fiberB = Q := by
  simp only [fiberB, fiberSourceZ, fiberSourceY, Q]
  ring_nf
  simp [ofNat_eq_mod_two_R2]

end Structural

end

end DimensionTwoCounterexample
